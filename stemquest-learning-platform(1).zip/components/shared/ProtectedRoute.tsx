'use client'
// ============================================================
// STEMQuest — ProtectedRoute
// Wraps pages that require authentication and/or a specific role.
// - Shows loading spinner during auth resolution
// - Redirects unauthenticated users to /login
// - Redirects authenticated users with wrong role to their own dashboard
// ============================================================

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import type { UserRole } from '@/lib/types'
import { Zap, ShieldX } from 'lucide-react'

interface ProtectedRouteProps {
  children: React.ReactNode
  /** If provided, only this exact role may view the page */
  requiredRole?: UserRole
  /** Override the default /login redirect for unauthenticated users */
  redirectTo?: string
}

function roleDashboard(role: UserRole): string {
  if (role === 'admin') return '/admin'
  return '/dashboard'
}

export default function ProtectedRoute({
  children,
  requiredRole,
  redirectTo = '/login',
}: ProtectedRouteProps) {
  const { session, loading } = useAuth()
  const router = useRouter()
  // Track whether we have already issued a redirect to avoid double-pushes
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (loading || redirecting) return

    if (!session) {
      setRedirecting(true)
      router.replace(redirectTo)
      return
    }

    if (requiredRole && session.role !== requiredRole) {
      setRedirecting(true)
      router.replace(roleDashboard(session.role))
    }
  }, [session, loading, requiredRole, redirectTo, router, redirecting])

  // ── Spinner while resolving auth ────────────────────────
  if (loading || redirecting) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center animate-pulse">
            <Zap className="h-6 w-6 text-primary" />
          </div>
          <p className="text-muted-foreground text-sm">Loading STEMQuest...</p>
        </div>
      </div>
    )
  }

  // ── Unauthenticated — render nothing (redirect in effect) ─
  if (!session) return null

  // ── Wrong role — show a polite forbidden message ─────────
  if (requiredRole && session.role !== requiredRole) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4 text-center px-4">
          <div className="h-14 w-14 rounded-xl bg-destructive/10 flex items-center justify-center">
            <ShieldX className="h-7 w-7 text-destructive" />
          </div>
          <p className="text-lg font-semibold text-foreground">Access Denied</p>
          <p className="text-sm text-muted-foreground max-w-xs">
            You do not have permission to view this page. Redirecting to your dashboard…
          </p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
