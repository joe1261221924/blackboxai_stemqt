'use client'
import Link from 'next/link'
import type { CourseItem } from '@/lib/api'
import { Lock, BookOpen, Clock, Star, ChevronRight } from 'lucide-react'

interface CourseCardProps {
  course:       CourseItem
  showProgress?: boolean
}

const difficultyColors: Record<string, string> = {
  beginner:     'bg-success/20 text-success',
  intermediate: 'bg-warning/20 text-warning',
  advanced:     'bg-destructive/20 text-destructive',
}

const categoryColors: Record<string, string> = {
  'Computer Science': 'bg-primary/20 text-primary',
  'Mathematics':      'bg-accent/20 text-accent',
  'Engineering':      'bg-[oklch(0.62_0.25_295)/0.2] text-[oklch(0.75_0.22_295)]',
  'Physics':          'bg-gold/20 text-gold',
}

export default function CourseCard({ course, showProgress = false }: CourseCardProps) {
  // Derive progress percentage and lesson counts from backend shape
  const pct              = course.progress?.percentage       ?? 0
  const completedLessons = course.progress?.completedLessons ?? 0

  return (
    <Link href={`/courses/${course.slug}`} className="block group">
      <div className="rounded-xl border border-border bg-card overflow-hidden card-hover h-full flex flex-col">
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden bg-secondary">
          <img
            src={
              course.imageUrl ||
              `https://placehold.co/800x450?text=${encodeURIComponent(course.title)}`
            }
            alt={`${course.title} course thumbnail`}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            onError={e => {
              ;(e.target as HTMLImageElement).src =
                `https://placehold.co/800x450?text=${encodeURIComponent(course.title)}`
            }}
          />
          {/* Premium badge */}
          {!course.isFree && (
            <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-full bg-[oklch(0.62_0.25_295)] text-white text-xs font-bold">
              <Lock className="h-3 w-3" />
              Premium
            </div>
          )}
          {/* Progress overlay */}
          {showProgress && course.isEnrolled && course.progress && (
            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-black/40">
              <div
                className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col flex-1 gap-3">
          {/* Tags */}
          <div className="flex flex-wrap gap-1.5">
            <span className={`badge-pill text-xs ${categoryColors[course.category] ?? 'bg-muted text-muted-foreground'}`}>
              {course.category}
            </span>
            <span className={`badge-pill text-xs ${difficultyColors[course.difficulty] ?? 'bg-muted text-muted-foreground'}`}>
              {course.difficulty}
            </span>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2 leading-snug">
            {course.title}
          </h3>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2 flex-1">{course.description}</p>

          {/* Meta */}
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <BookOpen className="h-3.5 w-3.5" />
              {course.totalLessons} lessons
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {course.estimatedHours}h
            </span>
            <span className="flex items-center gap-1 ml-auto truncate max-w-24" title={course.instructorName}>
              <Star className="h-3.5 w-3.5 text-gold fill-gold shrink-0" />
              <span className="truncate">{course.instructorName}</span>
            </span>
          </div>

          {/* Progress bar */}
          {showProgress && course.isEnrolled && course.progress && (
            <div>
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>{completedLessons}/{course.totalLessons} lessons</span>
                <span className="font-medium text-primary">{pct}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-bar-fill" style={{ width: `${pct}%` }} />
              </div>
            </div>
          )}

          {/* Price / CTA */}
          <div className="flex items-center justify-between pt-1 border-t border-border">
            <span className={`font-bold text-sm ${course.isFree ? 'text-success' : 'text-[oklch(0.75_0.22_295)]'}`}>
              {course.isFree ? 'Free' : `$${course.price.toFixed(2)}`}
            </span>
            <span className="flex items-center gap-1 text-xs font-medium text-primary group-hover:gap-2 transition-all">
              {course.isEnrolled ? 'Continue' : course.isFree ? 'Start Free' : 'View Course'}
              <ChevronRight className="h-3.5 w-3.5" />
            </span>
          </div>
        </div>
      </div>
    </Link>
  )
}
