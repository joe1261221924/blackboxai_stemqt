'use client'
// ============================================================
// STEMQuest — BadgeCard
// Renders a badge with a proper icon lookup (icon field is a
// Lucide name string so we map it to a real emoji/unicode
// character for display — avoids runtime dynamic import issues).
// ============================================================
import type { Badge } from '@/lib/types'

// Map from Lucide icon name stored in Badge.icon -> display emoji
const ICON_EMOJI: Record<string, string> = {
  Footprints:    '👣',
  Target:        '🎯',
  Flame:         '🔥',
  GraduationCap: '🎓',
  Zap:           '⚡',
  Trophy:        '🏆',
  Rocket:        '🚀',
  Star:          '⭐',
  BookOpen:      '📖',
}

interface BadgeCardProps {
  badge: Badge & { earnedAt?: string }
  size?: 'sm' | 'md' | 'lg'
  showDescription?: boolean
}

export default function BadgeCard({ badge, size = 'md', showDescription = false }: BadgeCardProps) {
  const sizeMap = {
    sm: { wrapper: 'p-2 gap-2', iconBox: 'h-9 w-9', iconText: 'text-lg', name: 'text-xs', desc: 'text-xs' },
    md: { wrapper: 'p-3 gap-3', iconBox: 'h-11 w-11', iconText: 'text-2xl', name: 'text-sm', desc: 'text-xs' },
    lg: { wrapper: 'p-4 gap-3', iconBox: 'h-14 w-14', iconText: 'text-3xl', name: 'text-base', desc: 'text-sm' },
  }
  const s = sizeMap[size]
  const iconEmoji = ICON_EMOJI[badge.icon] ?? '🏅'

  return (
    <div
      className={`flex items-center ${s.wrapper} rounded-xl border bg-card card-hover`}
      style={{ borderColor: `${badge.color}40` }}
    >
      <div
        className={`flex items-center justify-center rounded-lg ${s.iconBox} shrink-0 badge-glow`}
        style={{ background: `${badge.color}20` }}
        aria-hidden="true"
      >
        <span className={s.iconText} role="img" aria-label={badge.name}>
          {iconEmoji}
        </span>
      </div>
      <div className="min-w-0">
        <p className={`font-semibold text-foreground ${s.name} truncate`}>{badge.name}</p>
        {showDescription && (
          <p className={`text-muted-foreground ${s.desc} mt-0.5 line-clamp-2`}>{badge.description}</p>
        )}
        {badge.earnedAt && (
          <p className="text-xs text-muted-foreground mt-0.5">
            Earned {new Date(badge.earnedAt).toLocaleDateString()}
          </p>
        )}
      </div>
    </div>
  )
}
