'use client'
import type { LucideIcon } from 'lucide-react'

interface StatCardProps {
  label: string
  value: string | number
  icon: LucideIcon
  color?: 'blue' | 'cyan' | 'gold' | 'green' | 'purple' | 'red'
  sublabel?: string
  className?: string
}

const colorMap = {
  blue:   { bg: 'bg-primary/15',  text: 'text-primary',     icon: 'text-primary' },
  cyan:   { bg: 'bg-accent/15',   text: 'text-accent',      icon: 'text-accent' },
  gold:   { bg: 'bg-gold/15',     text: 'text-gold',        icon: 'text-gold' },
  green:  { bg: 'bg-success/15',  text: 'text-success',     icon: 'text-success' },
  purple: { bg: 'bg-[oklch(0.62_0.25_295)/0.15]', text: 'text-[oklch(0.75_0.22_295)]', icon: 'text-[oklch(0.75_0.22_295)]' },
  red:    { bg: 'bg-destructive/15', text: 'text-destructive', icon: 'text-destructive' },
}

export default function StatCard({ label, value, icon: Icon, color = 'blue', sublabel, className = '' }: StatCardProps) {
  const c = colorMap[color]
  return (
    <div className={`rounded-xl border border-border bg-card p-5 card-hover ${className}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground font-medium">{label}</p>
          <p className={`text-3xl font-bold mt-1 ${c.text}`}>{value}</p>
          {sublabel && <p className="text-xs text-muted-foreground mt-1">{sublabel}</p>}
        </div>
        <div className={`p-3 rounded-lg ${c.bg}`}>
          <Icon className={`h-5 w-5 ${c.icon}`} />
        </div>
      </div>
    </div>
  )
}
