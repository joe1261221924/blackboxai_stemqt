'use client'
// ============================================================
// STEMQuest — AuthContext
// Cookie-based JWT auth via real Flask backend.
// Calls POST /api/auth/login|register|logout and GET /api/auth/me
// ============================================================

import React, {
  createContext, useContext, useState, useEffect, useCallback,
} from 'react'
import { authApi, ApiError, type AuthUser, type GamificationSummary } from '@/lib/api'

// ── Session shape ────────────────────────────────────────────
export interface AuthSession {
  userId:         string
  email:          string
  name:           string
  role:           'student' | 'admin'
  avatar:         string
  gamification:   GamificationSummary | null
}

interface AuthContextValue {
  session:         AuthSession | null
  loading:         boolean
  login:           (email: string, password: string) => Promise<{ error?: string }>
  register:        (email: string, name: string, password: string) => Promise<{ error?: string }>
  logout:          () => Promise<void>
  isAuthenticated: boolean
  isRole:          (role: 'student' | 'admin') => boolean
  refreshSession:  () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

function userToSession(user: AuthUser, gami: GamificationSummary | null): AuthSession {
  return {
    userId:       user.id,
    email:        user.email,
    name:         user.name,
    role:         user.role,
    avatar:       user.avatar,
    gamification: gami,
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(null)
  const [loading, setLoading] = useState(true)

  // Restore session on mount by calling /me (uses HTTP-only cookie)
  const refreshSession = useCallback(async () => {
    try {
      const { user, gamification } = await authApi.me()
      setSession(userToSession(user, gamification))
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setSession(null)
      } else {
        // Network error — keep existing session if any
        console.warn('[STEMQuest] Could not refresh session:', err)
      }
    }
  }, [])

  useEffect(() => {
    refreshSession().finally(() => setLoading(false))
  }, [refreshSession])

  const login = useCallback(
    async (email: string, password: string): Promise<{ error?: string }> => {
      try {
        const { user } = await authApi.login(email.trim().toLowerCase(), password)
        // After login the cookie is set; fetch gamification via /me for students
        let gami: GamificationSummary | null = null
        if (user.role === 'student') {
          try {
            const me = await authApi.me()
            gami = me.gamification
          } catch { /* non-critical */ }
        }
        setSession(userToSession(user, gami))
        return {}
      } catch (err) {
        if (err instanceof ApiError) return { error: err.message }
        return { error: 'Login failed. Please try again.' }
      }
    },
    [],
  )

  const register = useCallback(
    async (email: string, name: string, password: string): Promise<{ error?: string }> => {
      try {
        const { user } = await authApi.register(email.trim().toLowerCase(), name.trim(), password)
        setSession(userToSession(user, null))
        return {}
      } catch (err) {
        if (err instanceof ApiError) return { error: err.message }
        return { error: 'Registration failed. Please try again.' }
      }
    },
    [],
  )

  const logout = useCallback(async () => {
    try {
      await authApi.logout()
    } catch {
      // Swallow errors — clear session regardless
    } finally {
      setSession(null)
    }
  }, [])

  const isRole = useCallback(
    (role: 'student' | 'admin') => session?.role === role,
    [session],
  )

  return (
    <AuthContext.Provider
      value={{
        session,
        loading,
        login,
        register,
        logout,
        isAuthenticated: !!session,
        isRole,
        refreshSession,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
