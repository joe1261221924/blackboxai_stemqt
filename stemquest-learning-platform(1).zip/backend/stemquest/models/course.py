"""
Course model
============
Represents a published or draft STEM course.

Design notes
------------
* ``is_premium`` flag: True means payment is required; False means the course
  is freely accessible to any enrolled user.
* ``price`` is nullable: free courses carry NULL, premium courses carry a
  non-null Numeric(10,2) value.  A non-null server_default of "0.00" was
  removed to match the spec (nullable price on free courses).
* ``published`` defaults to True so newly created courses are immediately
  visible; admins must explicitly unpublish (draft) a course.
* ``instructor_id`` is a nullable FK pointing to the admin who authored the
  course.  SET NULL on delete keeps the course alive if that admin is removed.
  It never implies a "teacher" role — only student/admin roles exist.
* ``slug`` has a B-tree unique index — the public URL key.
* A composite index on ``(published, difficulty)`` backs the catalogue query.
* ``tags`` is a JSON array; no join table needed for the current feature set.
* ``updated_at`` uses ``onupdate`` so SQLAlchemy fires it automatically.
* ``pending_orders`` relationship added so admin dashboards can surface
  in-flight payment orders per course without a raw query.
"""
from __future__ import annotations

import enum

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

from ..extensions import db


class Difficulty(str, enum.Enum):
    beginner     = "beginner"
    intermediate = "intermediate"
    advanced     = "advanced"


class Course(db.Model):
    __tablename__ = "courses"
    __table_args__ = (
        # Composite index: catalogue query filters on both columns simultaneously.
        db.Index("ix_courses_published_difficulty", "published", "difficulty"),
    )

    id          = db.Column(
                      UUID(as_uuid=False),
                      primary_key=True,
                      server_default=db.text("gen_random_uuid()"),
                  )
    slug        = db.Column(db.String(200), unique=True, nullable=False, index=True)
    title       = db.Column(db.String(300), nullable=False)
    # Spec: description is nullable text.
    description = db.Column(db.Text, nullable=True)
    image_url   = db.Column(db.Text, nullable=True)

    # Nullable: records which admin created/owns this course.
    # SET NULL on delete so the course survives if the admin account is removed.
    instructor_id = db.Column(
                        UUID(as_uuid=False),
                        db.ForeignKey("users.id", ondelete="SET NULL"),
                        nullable=True,
                        index=True,
                    )

    # Premium / pricing
    # Spec: free courses may carry null price; premium courses must have a price.
    is_premium  = db.Column(db.Boolean,        nullable=False, server_default=sa.false())
    price       = db.Column(db.Numeric(10, 2), nullable=True)   # NULL == free
    currency    = db.Column(db.String(3),      nullable=False,  server_default="USD")

    # Publication state — spec default: true (published immediately on creation).
    published   = db.Column(db.Boolean, nullable=False, server_default=sa.true(), index=True)

    # Extended metadata (beyond spec minimum; all additive, non-breaking)
    category        = db.Column(db.String(100),   nullable=False, server_default="")
    difficulty      = db.Column(
                          db.Enum(Difficulty, name="difficulty"),
                          nullable=False,
                          default=Difficulty.beginner,
                          server_default=Difficulty.beginner.value,
                      )
    tags            = db.Column(db.JSON,          nullable=False, default=list, server_default="[]")
    total_lessons   = db.Column(db.Integer,       nullable=False, server_default="0")
    estimated_hours = db.Column(db.Numeric(5, 1), nullable=False, server_default="0")

    created_at  = db.Column(
                      db.DateTime(timezone=True),
                      nullable=False,
                      server_default=db.text("now()"),
                  )
    updated_at  = db.Column(
                      db.DateTime(timezone=True),
                      nullable=False,
                      server_default=db.text("now()"),
                      onupdate=db.text("now()"),
                  )

    # ── Relationships ──────────────────────────────────────────────────────
    instructor  = db.relationship("User", foreign_keys=[instructor_id])

    modules     = db.relationship(
                      "Module", back_populates="course",
                      order_by="Module.sort_order", lazy="dynamic",
                      cascade="all, delete-orphan",
                  )
    enrollments = db.relationship(
                      "Enrollment", back_populates="course",
                      lazy="dynamic", cascade="all, delete-orphan",
                  )
    # RESTRICT delete on purchases — financial records must not be silently
    # removed when a course is deleted.  Handled at FK level in Purchase.
    purchases   = db.relationship(
                      "Purchase", back_populates="course", lazy="dynamic",
                  )
    # In-flight payment orders for this course (admin visibility).
    pending_orders = db.relationship(
                         "PendingOrder", back_populates="course", lazy="dynamic",
                     )

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":              self.id,
            "slug":            self.slug,
            "title":           self.title,
            "description":     self.description,
            "image_url":       self.image_url,
            "instructor_id":   self.instructor_id,
            "instructor_name": self.instructor.name if self.instructor else "STEMQuest Team",
            "is_premium":      self.is_premium,
            # Serialise Numeric as float; None for free courses.
            "price":           float(self.price) if self.price is not None else None,
            "currency":        self.currency,
            "published":       self.published,
            "category":        self.category,
            "difficulty":      self.difficulty.value,
            "tags":            self.tags or [],
            "total_lessons":   self.total_lessons,
            "estimated_hours": float(self.estimated_hours),
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "updated_at":      self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        return f"<Course {self.slug}>"
