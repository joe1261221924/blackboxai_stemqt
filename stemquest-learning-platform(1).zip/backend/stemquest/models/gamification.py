"""
Gamification models
===================
PointsTransaction, Badge, UserBadge, UserStreak

Design notes
------------
PointsTransaction
  * ``amount`` is the canonical field name (matches spec).
  * ``idempotency_key`` is nullable per spec ("nullable, unique where used").
    The service layer sets a deterministic key (e.g.
    ``"lesson_complete:{user_id}:{lesson_id}"``) on every programmatic XP
    award; rows inserted by an admin CLI command may omit it.  The UNIQUE
    constraint is conditional: PostgreSQL treats multiple NULLs in a unique
    index as distinct, so nullable + unique is safe.
  * Composite index on ``(user_id, created_at)`` enables the
    "fetch all transactions for a user sorted by time" query pattern needed
    for the activity feed and leaderboard aggregation.

Badge
  * ``slug`` is the machine-readable identifier used in badge-unlock logic.
  * ``points_required`` is nullable: NULL means no XP gate (e.g. signup badge,
    first-lesson badge).  Spec default was 0; nullable is more expressive and
    avoids a spurious XP check for non-XP badges.
  * ``created_at`` added for schema consistency.

UserBadge
  * ``awarded_at`` is the canonical timestamp (matches spec).
  * ``created_at`` mirrors the insert time (schema consistency).
  * Unique constraint on ``(user_id, badge_id)`` prevents duplicates.

UserStreak
  * ``last_activity_date`` is a native ``db.Date`` column enabling date
    arithmetic in SQL (e.g. ``last_activity_date = CURRENT_DATE - 1``).
  * One row per user, enforced by ``unique=True`` on ``user_id``.
"""
from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

from ..extensions import db


class PointsTransaction(db.Model):
    __tablename__ = "points_transactions"
    __table_args__ = (
        # UNIQUE on idempotency_key where non-null; PostgreSQL treats NULLs as
        # distinct in a unique index, so nullable + unique is correct here.
        db.UniqueConstraint("idempotency_key", name="uq_points_idempotency_key"),
        # Fast aggregation for leaderboard / activity feed.
        db.Index("ix_points_user_created", "user_id", "created_at"),
        # Allow quick lookup of a specific key without a full-table scan.
        db.Index("ix_points_idempotency_key", "idempotency_key"),
    )

    id              = db.Column(
                          UUID(as_uuid=False),
                          primary_key=True,
                          server_default=db.text("gen_random_uuid()"),
                      )
    user_id         = db.Column(
                          UUID(as_uuid=False),
                          db.ForeignKey("users.id", ondelete="CASCADE"),
                          nullable=False,
                          index=True,
                      )
    # Spec: amount integer, not null.
    amount          = db.Column(db.Integer,     nullable=False)
    # Spec: reason string, not null.
    reason          = db.Column(db.String(500), nullable=False, server_default="")
    # Spec: idempotency_key nullable, unique where used.
    # nullable=True + unique constraint = PostgreSQL allows multiple NULLs.
    idempotency_key = db.Column(db.String(255), nullable=True, unique=True)
    created_at      = db.Column(
                          db.DateTime(timezone=True),
                          nullable=False,
                          server_default=db.text("now()"),
                      )

    # ── Relationships ──────────────────────────────────────────────────────
    user = db.relationship("User", back_populates="points_transactions")

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":              self.id,
            "user_id":         self.user_id,
            "amount":          self.amount,
            "reason":          self.reason,
            "idempotency_key": self.idempotency_key,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return f"<PointsTransaction user={self.user_id} amount={self.amount}>"


class Badge(db.Model):
    __tablename__ = "badges"
    __table_args__ = (
        db.UniqueConstraint("slug", name="uq_badge_slug"),
    )

    id              = db.Column(
                          UUID(as_uuid=False),
                          primary_key=True,
                          server_default=db.text("gen_random_uuid()"),
                      )
    # Machine-readable identifier used in unlock logic (e.g. "signup", "xp_100")
    slug            = db.Column(db.String(100), nullable=False, unique=True)
    title           = db.Column(db.String(150), nullable=False)
    description     = db.Column(db.Text,        nullable=False, server_default="")
    # Optional XP threshold gate; NULL means no XP requirement
    points_required = db.Column(db.Integer,     nullable=True)
    created_at      = db.Column(
                          db.DateTime(timezone=True),
                          nullable=False,
                          server_default=db.text("now()"),
                      )

    # ── Relationships ──────────────────────────────────────────────────────
    user_badges = db.relationship(
                      "UserBadge", back_populates="badge",
                      lazy="dynamic", cascade="all, delete-orphan",
                  )

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":              self.id,
            "slug":            self.slug,
            "title":           self.title,
            "description":     self.description,
            "points_required": self.points_required,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return f"<Badge {self.slug!r}>"


class UserBadge(db.Model):
    __tablename__ = "user_badges"
    __table_args__ = (
        # A student can hold each badge only once
        db.UniqueConstraint("user_id", "badge_id", name="uq_user_badge"),
        db.Index("ix_user_badges_user", "user_id"),
    )

    id         = db.Column(
                     UUID(as_uuid=False),
                     primary_key=True,
                     server_default=db.text("gen_random_uuid()"),
                 )
    user_id    = db.Column(
                     UUID(as_uuid=False),
                     db.ForeignKey("users.id",   ondelete="CASCADE"),
                     nullable=False,
                     index=True,
                 )
    badge_id   = db.Column(
                     UUID(as_uuid=False),
                     db.ForeignKey("badges.id",  ondelete="CASCADE"),
                     nullable=False,
                     index=True,
                 )
    awarded_at = db.Column(
                     db.DateTime(timezone=True),
                     nullable=False,
                     server_default=db.text("now()"),
                 )
    created_at = db.Column(
                     db.DateTime(timezone=True),
                     nullable=False,
                     server_default=db.text("now()"),
                 )

    # ── Relationships ──────────────────────────────────────────────────────
    user  = db.relationship("User",  back_populates="user_badges")
    badge = db.relationship("Badge", back_populates="user_badges")

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":        self.id,
            "user_id":   self.user_id,
            "badge_id":  self.badge_id,
            "awarded_at": self.awarded_at.isoformat() if self.awarded_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "badge":      self.badge.to_dict() if self.badge else None,
        }

    def __repr__(self) -> str:
        return f"<UserBadge user={self.user_id} badge={self.badge_id}>"


class UserStreak(db.Model):
    __tablename__ = "user_streaks"

    id                 = db.Column(
                             UUID(as_uuid=False),
                             primary_key=True,
                             server_default=db.text("gen_random_uuid()"),
                         )
    user_id            = db.Column(
                             UUID(as_uuid=False),
                             db.ForeignKey("users.id", ondelete="CASCADE"),
                             nullable=False,
                             unique=True,   # one streak record per user
                             index=True,
                         )
    current_streak     = db.Column(db.Integer, nullable=False, server_default="0")
    longest_streak     = db.Column(db.Integer, nullable=False, server_default="0")
    # Native Date column: enables date arithmetic in SQL (e.g. activity_date = today - 1)
    last_activity_date = db.Column(db.Date,    nullable=True)
    created_at         = db.Column(
                             db.DateTime(timezone=True),
                             nullable=False,
                             server_default=db.text("now()"),
                         )
    updated_at         = db.Column(
                             db.DateTime(timezone=True),
                             nullable=False,
                             server_default=db.text("now()"),
                             onupdate=db.text("now()"),
                         )

    # ── Relationships ──────────────────────────────────────────────────────
    user = db.relationship("User", back_populates="streak")

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":                 self.id,
            "user_id":            self.user_id,
            "current_streak":     self.current_streak,
            "longest_streak":     self.longest_streak,
            "last_activity_date": (
                self.last_activity_date.isoformat() if self.last_activity_date else None
            ),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        return (
            f"<UserStreak user={self.user_id} "
            f"current={self.current_streak} longest={self.longest_streak}>"
        )
