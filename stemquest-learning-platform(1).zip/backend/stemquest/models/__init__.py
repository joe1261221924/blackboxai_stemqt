"""
STEMQuest — Models package
===========================
All SQLAlchemy models are imported here so that:
  1. Flask-Migrate's ``db.create_all()`` / Alembic ``env.py`` can discover
     every table by importing this single package.
  2. Services can do ``from stemquest.models import User, Course, …`` rather
     than navigating individual sub-modules.

Import order matters: models with FK dependencies must be imported AFTER the
tables they reference.  The order below satisfies all FK chains:

  users
    ↳ courses   (instructor_id → users.id, SET NULL)
        ↳ modules        (course_id → courses.id, CASCADE)
            ↳ lessons    (module_id → modules.id, course_id → courses.id, CASCADE)
                ↳ quizzes               (lesson_id → lessons.id, CASCADE, UNIQUE)
                    ↳ quiz_questions    (quiz_id → quizzes.id, CASCADE)
                        ↳ quiz_options  (question_id → quiz_questions.id, CASCADE)
                ↳ quiz_attempts         (user_id → users.id, quiz_id → quizzes.id,
                                          lesson_id → lessons.id, CASCADE)
                ↳ lesson_progress       (user_id → users.id, lesson_id → lessons.id,
                                          course_id → courses.id, CASCADE)
        ↳ enrollments    (user_id → users.id, course_id → courses.id, CASCADE)
  gamification (user_id → users.id, badge_id → badges.id, CASCADE)
  billing:
    ↳ purchases      (user_id → users.id RESTRICT, course_id → courses.id RESTRICT)
    ↳ pending_orders (user_id → users.id, course_id → courses.id, CASCADE)
    ↳ webhook_events (standalone — no FKs)

Spec relationship map (implemented and verified)
-------------------------------------------------
User          → enrollments, lesson_progress, quiz_attempts,
                points_transactions, user_badges, streak, purchases,
                pending_orders
Course        → modules, enrollments, purchases, pending_orders
Module        → course, lessons
Lesson        → module, course, quizzes, progress_records
                (``lesson.quiz`` is a convenience property → quizzes.first())
Quiz          → lesson, questions, attempts
QuizQuestion  → quiz, options
QuizOption    → question
Enrollment    → user, course
LessonProgress→ user, lesson
QuizAttempt   → user, quiz, lesson (denormalized)
PointsTx      → user
Badge         → user_badges
UserBadge     → user, badge
UserStreak    → user
Purchase      → user, course
PendingOrder  → user, course
WebhookEvent  → (no ORM relationships — standalone audit log)

Roles
-----
Only two roles exist: UserRole.student and UserRole.admin.
The teacher role has been explicitly removed from the schema.
"""
from .user         import User, UserRole
from .course       import Course, Difficulty
from .module       import Module
from .lesson       import Lesson
from .enrollment   import Enrollment
from .progress     import LessonProgress
from .quiz         import (
    Quiz,
    QuizQuestion,
    QuizOption,
    QuizAttempt,
    Recommendation,
)
from .gamification import PointsTransaction, Badge, UserBadge, UserStreak
from .billing      import (
    Purchase,
    PurchaseStatus,
    PendingOrder,
    PendingOrderStatus,
    WebhookEvent,
)

__all__ = [
    # Auth / identity
    "User",
    "UserRole",
    # Content hierarchy
    "Course",
    "Difficulty",
    "Module",
    "Lesson",
    # Learning flow
    "Enrollment",
    "LessonProgress",
    # Assessment
    "Quiz",
    "QuizQuestion",
    "QuizOption",
    "QuizAttempt",
    "Recommendation",
    # Gamification
    "PointsTransaction",
    "Badge",
    "UserBadge",
    "UserStreak",
    # Billing / payments
    "Purchase",
    "PurchaseStatus",
    "PendingOrder",
    "PendingOrderStatus",
    "WebhookEvent",
]
