"""
Billing models
==============
Purchase, PendingOrder, WebhookEvent

Design notes
------------
Purchase
  * ``provider`` records the payment gateway used (default "paypal") so the
    schema is not PayPal-specific and accommodates future providers (Stripe,
    etc.) without a migration.
  * ``provider_payment_id`` is NULLABLE per spec ("nullable, unique where
    applicable").  It is set only after a successful capture; a row may exist
    briefly before capture with a NULL value.  The UNIQUE constraint combined
    with nullable is safe in PostgreSQL because NULL values are treated as
    distinct in a unique index.
  * ``status`` uses a named PostgreSQL enum type for clean DB-level constraint
    enforcement and readable query output.
  * FK ondelete="RESTRICT" on both user_id and course_id: financial records
    must not be silently lost when an account or course is removed.
  * ``completed_at`` is set when the purchase transitions to ``completed``.

PendingOrder
  * ``provider_order_id`` is the canonical field name (matches spec).
  * ``status`` tracks the lifecycle: "pending" → "captured" | "expired".
  * ``expires_at`` is enforced by the service layer (not a DB trigger) so
    that expired orders can be surfaced in admin queries.
  * ``back_populates="pending_orders"`` must match Course.pending_orders and
    User.pending_orders.

WebhookEvent
  * ``event_id`` is the gateway-supplied idempotency key (e.g. PayPal's
    ``PAYPAL-TRANSMISSION-ID`` header).  A unique constraint ensures
    exactly-once processing.
  * ``raw_payload`` is stored as ``db.Text`` (verbatim JSON string) per spec,
    NOT ``db.JSON``.  Storing as text preserves the exact byte-for-byte
    payload for signature verification and replay; auto-parsing by SQLAlchemy
    would mutate the payload and break HMAC checks.
  * ``processed`` boolean flag — False = received/queued, True = processed.
    Simple and sufficient for basic deduplication; a more complex state
    machine can be layered on top in the future without a schema migration.
"""
from __future__ import annotations

import enum

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

from ..extensions import db


class PurchaseStatus(str, enum.Enum):
    pending   = "pending"
    completed = "completed"
    failed    = "failed"
    refunded  = "refunded"


class PendingOrderStatus(str, enum.Enum):
    pending  = "pending"
    captured = "captured"
    expired  = "expired"


class Purchase(db.Model):
    __tablename__ = "purchases"
    __table_args__ = (
        # Guard against double-fulfillment for the same gateway payment capture.
        # nullable=True + unique = PostgreSQL allows multiple NULLs (pre-capture rows).
        db.UniqueConstraint("provider_payment_id", name="uq_purchase_provider_payment"),
        # Most common admin query: all purchases for a user on a course.
        db.Index("ix_purchase_user_course",    "user_id",  "course_id"),
        # Used by admin dashboard to filter by fulfilment status.
        db.Index("ix_purchase_user_status",    "user_id",  "status"),
        # Used by billing service to look up a capture by provider + payment ID.
        db.Index("ix_purchase_provider_order", "provider", "provider_payment_id"),
    )

    id                  = db.Column(
                              UUID(as_uuid=False),
                              primary_key=True,
                              server_default=db.text("gen_random_uuid()"),
                          )
    user_id             = db.Column(
                              UUID(as_uuid=False),
                              # RESTRICT: financial records must not vanish on account deletion.
                              db.ForeignKey("users.id",   ondelete="RESTRICT"),
                              nullable=False,
                              index=True,
                          )
    course_id           = db.Column(
                              UUID(as_uuid=False),
                              # RESTRICT: purchases must not vanish when a course is removed.
                              db.ForeignKey("courses.id", ondelete="RESTRICT"),
                              nullable=False,
                              index=True,
                          )
    # Spec: amount numeric/decimal, not null.
    amount              = db.Column(db.Numeric(10, 2), nullable=False)
    # Spec: currency string(3), default USD.
    currency            = db.Column(db.String(3),      nullable=False, server_default="USD")
    # Spec: provider string, default paypal.
    provider            = db.Column(db.String(50),     nullable=False, server_default="paypal")
    # Spec: provider_payment_id is nullable (set post-capture), unique where non-null.
    provider_payment_id = db.Column(db.String(128), nullable=True, unique=True)
    # Spec: status string, default fulfilled — using "completed" (PurchaseStatus enum).
    status              = db.Column(
                              db.Enum(PurchaseStatus, name="purchasestatus"),
                              nullable=False,
                              default=PurchaseStatus.pending,
                              server_default=PurchaseStatus.pending.value,
                          )
    # Spec: created_at datetime, default utcnow.
    created_at          = db.Column(
                              db.DateTime(timezone=True),
                              nullable=False,
                              server_default=db.text("now()"),
                          )
    # Extra: timestamp of fulfilment transition.
    completed_at        = db.Column(db.DateTime(timezone=True), nullable=True)

    # ── Relationships ──────────────────────────────────────────────────────
    user   = db.relationship("User",   back_populates="purchases")
    course = db.relationship("Course", back_populates="purchases")

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":                  self.id,
            "user_id":             self.user_id,
            "course_id":           self.course_id,
            "amount":              float(self.amount),
            "currency":            self.currency,
            "provider":            self.provider,
            "provider_payment_id": self.provider_payment_id,
            "status":              self.status.value,
            "created_at":          self.created_at.isoformat()  if self.created_at  else None,
            "completed_at":        self.completed_at.isoformat() if self.completed_at else None,
            # Convenience fields for admin/receipt views.
            "course_title":        self.course.title if self.course else None,
            "user_email":          self.user.email   if self.user   else None,
        }

    def __repr__(self) -> str:
        return (
            f"<Purchase user={self.user_id} course={self.course_id} "
            f"status={self.status.value}>"
        )


class PendingOrder(db.Model):
    """
    Short-lived record linking a provider order ID to a user + course before
    payment is captured.  Lifecycle: pending → captured | expired.
    Expiry is enforced by the service layer (not a DB trigger).
    """
    __tablename__ = "pending_orders"
    __table_args__ = (
        # One provider order ID maps to exactly one pending_order row.
        db.UniqueConstraint("provider_order_id", name="uq_pending_provider_order"),
        db.Index("ix_pending_orders_user",           "user_id"),
        db.Index("ix_pending_orders_course",         "course_id"),
        db.Index("ix_pending_orders_status_created", "status", "created_at"),
    )

    id                = db.Column(
                            UUID(as_uuid=False),
                            primary_key=True,
                            server_default=db.text("gen_random_uuid()"),
                        )
    # Spec: provider_order_id string, unique, not null.
    provider_order_id = db.Column(db.String(128), nullable=False, unique=True)
    user_id           = db.Column(
                            UUID(as_uuid=False),
                            db.ForeignKey("users.id",   ondelete="CASCADE"),
                            nullable=False,
                            index=True,
                        )
    course_id         = db.Column(
                            UUID(as_uuid=False),
                            db.ForeignKey("courses.id", ondelete="CASCADE"),
                            nullable=False,
                            index=True,
                        )
    # Spec: status string, default created — using the PendingOrderStatus enum.
    status            = db.Column(
                            db.Enum(PendingOrderStatus, name="pendingorderstatus"),
                            nullable=False,
                            default=PendingOrderStatus.pending,
                            server_default=PendingOrderStatus.pending.value,
                        )
    # Spec: created_at datetime, default utcnow.
    created_at        = db.Column(
                            db.DateTime(timezone=True),
                            nullable=False,
                            server_default=db.text("now()"),
                        )
    # Extra: expiry timestamp set by service layer at order creation time.
    amount            = db.Column(db.Numeric(10, 2), nullable=False)
    currency          = db.Column(db.String(3),      nullable=False, server_default="USD")
    provider          = db.Column(db.String(50),     nullable=False, server_default="paypal")
    expires_at        = db.Column(db.DateTime(timezone=True), nullable=False)

    # ── Relationships ──────────────────────────────────────────────────────
    user   = db.relationship("User",   back_populates="pending_orders")
    # back_populates must equal "pending_orders" — the relationship added to Course.
    course = db.relationship("Course", back_populates="pending_orders")

    # ── Serialization ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":                self.id,
            "provider_order_id": self.provider_order_id,
            "user_id":           self.user_id,
            "course_id":         self.course_id,
            "amount":            float(self.amount),
            "currency":          self.currency,
            "provider":          self.provider,
            "status":            self.status.value,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "expires_at":        self.expires_at.isoformat()  if self.expires_at  else None,
        }

    def __repr__(self) -> str:
        return (
            f"<PendingOrder provider_order={self.provider_order_id} "
            f"status={self.status.value}>"
        )


class WebhookEvent(db.Model):
    """
    Verbatim log of every inbound webhook event.  Used for:
    - Exactly-once processing (event_id unique constraint).
    - Auditability (raw_payload stored as Text for byte-faithful replay).
    - Admin tooling (unprocessed events can be replayed via CLI).
    """
    __tablename__ = "webhook_events"
    __table_args__ = (
        # Ensures each provider event is processed exactly once.
        db.UniqueConstraint("event_id", name="uq_webhook_event_id"),
        # Admin query: fetch all unprocessed events in arrival order.
        db.Index("ix_webhook_events_processed_created", "processed", "created_at"),
        # Enables filtering by provider (paypal, stripe, etc.) in admin views.
        db.Index("ix_webhook_events_provider", "provider"),
        # Fast lookup of a specific event_id without a seq scan.
        db.Index("ix_webhook_events_event_id", "event_id"),
    )

    id          = db.Column(
                      UUID(as_uuid=False),
                      primary_key=True,
                      server_default=db.text("gen_random_uuid()"),
                  )
    # Spec: provider string, not null.
    provider    = db.Column(db.String(50),  nullable=False, server_default="paypal")
    # Spec: event_id string, unique, not null (gateway-supplied idempotency key).
    event_id    = db.Column(db.String(128), nullable=False, unique=True)
    # Spec: raw_payload text, not null.
    # Stored as db.Text (NOT db.JSON) to preserve the verbatim byte-for-byte
    # payload — required for HMAC signature verification and exact replay.
    raw_payload = db.Column(db.Text, nullable=False)
    # Spec: processed boolean, default false.
    processed   = db.Column(db.Boolean, nullable=False, server_default=sa.false())
    # Spec: created_at datetime, default utcnow.
    created_at  = db.Column(
                      db.DateTime(timezone=True),
                      nullable=False,
                      server_default=db.text("now()"),
                  )

    # ── Serialization ──────────────────────────────────────────────────────
    # raw_payload intentionally omitted — it may contain sensitive data and
    # can be very large; callers that need it should access the column directly.
    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "provider":   self.provider,
            "event_id":   self.event_id,
            "processed":  self.processed,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return (
            f"<WebhookEvent provider={self.provider} "
            f"event_id={self.event_id} processed={self.processed}>"
        )
