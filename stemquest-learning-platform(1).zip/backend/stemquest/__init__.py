"""
STEMQuest — Application Factory
================================
Creates and configures the Flask application.

Startup order
-------------
1. Load configuration object.
2. Validate production-safety rules (skipped in DEBUG/TESTING).
3. Initialise SQLAlchemy, Migrate, JWT, CORS, Bcrypt, Limiter.
4. Initialise Redis + RQ via ``init_redis(app)``.
5. Import and register all models so Alembic/Flask-Migrate can discover them.
6. Register JWT error handlers.
7. Register API Blueprints.
8. Register generic HTTP error handlers.
9. Register CLI commands.
"""
from __future__ import annotations

from flask import Flask, jsonify

from .config import get_config, ConfigError
from .extensions import db, migrate, jwt, cors, limiter, bcrypt, init_redis


def create_app(env: str | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=False)

    # ── Configuration ──────────────────────────────────────────────────────
    cfg = get_config(env)
    app.config.from_object(cfg)
    try:
        cfg.validate()
    except ConfigError as exc:
        app.logger.warning("Config validation: %s", exc)

    # ── SQLAlchemy extensions ──────────────────────────────────────────────
    db.init_app(app)
    migrate.init_app(app, db)

    # ── Auth / Security ────────────────────────────────────────────────────
    jwt.init_app(app)
    bcrypt.init_app(app)

    # ── CORS ───────────────────────────────────────────────────────────────
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}},
        supports_credentials=True,
    )

    # ── Rate limiting ──────────────────────────────────────────────────────
    limiter.init_app(app)

    # ── Redis + RQ ─────────────────────────────────────────────────────────
    # Must happen before any blueprint code that calls get_redis() or
    # get_task_queue().  The TestingConfig uses RATELIMIT_ENABLED=False so
    # rate limiter does not touch Redis during tests.
    init_redis(app)

    # ── Model discovery ────────────────────────────────────────────────────
    # Import here (inside factory) to ensure models register with the correct
    # SQLAlchemy metadata instance and to avoid circular imports at module level.
    with app.app_context():
        from . import models as _models  # noqa: F401

    # ── JWT error handlers ─────────────────────────────────────────────────
    @jwt.unauthorized_loader
    def unauthorized_callback(reason: str):
        return jsonify({"error": "Authentication required", "detail": reason}), 401

    @jwt.invalid_token_loader
    def invalid_token_callback(reason: str):
        return jsonify({"error": "Invalid token", "detail": reason}), 401

    @jwt.expired_token_loader
    def expired_token_callback(_header, _payload):
        return jsonify({"error": "Token has expired"}), 401

    @jwt.revoked_token_loader
    def revoked_token_callback(_header, _payload):
        return jsonify({"error": "Token has been revoked"}), 401

    # ── Blueprints ─────────────────────────────────────────────────────────
    from .routes.health       import bp as health_bp
    from .routes.auth         import bp as auth_bp
    from .routes.courses      import bp as courses_bp
    from .routes.gamification import bp as gamification_bp
    from .routes.billing      import bp as billing_bp
    from .routes.webhooks     import bp as webhooks_bp
    from .routes.admin        import bp as admin_bp

    app.register_blueprint(health_bp)
    app.register_blueprint(auth_bp,          url_prefix="/api/auth")
    app.register_blueprint(courses_bp,       url_prefix="/api/courses")
    app.register_blueprint(gamification_bp,  url_prefix="/api/gamification")
    app.register_blueprint(billing_bp,       url_prefix="/api/billing")
    app.register_blueprint(webhooks_bp,      url_prefix="/api/webhooks")
    app.register_blueprint(admin_bp,         url_prefix="/api/admin")

    # ── Generic error handlers ─────────────────────────────────────────────
    from .utils.errors import register_error_handlers
    register_error_handlers(app)

    # ── CLI commands ───────────────────────────────────────────────────────
    from .commands import register_commands
    register_commands(app)

    return app
