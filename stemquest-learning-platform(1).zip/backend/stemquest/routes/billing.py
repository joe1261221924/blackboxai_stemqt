"""
STEMQuest — Billing routes

POST /api/billing/create-order  — student: create PayPal order for a premium course
POST /api/billing/capture       — student: capture confirmed order and unlock enrollment

FIELD NAMING
------------
The request body for ``capture`` uses ``provider_order_id`` (not ``paypal_order_id``).
This mirrors the PendingOrder model's canonical field name and makes the route
provider-agnostic (future Stripe support, etc.).
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from ..services import billing as billing_svc
from ..utils.auth import jwt_required_custom, get_current_user
from ..utils.validators import require_json
from ..utils.errors import ValidationError
from ..extensions import limiter

bp = Blueprint("billing", __name__)

_BILLING_LIMIT = "20 per minute"


@bp.post("/create-order")
@limiter.limit(_BILLING_LIMIT)
@jwt_required_custom
def create_order():
    data      = require_json()
    course_id = (data.get("course_id") or "").strip()
    if not course_id:
        raise ValidationError("Validation failed.", detail={"course_id": "Required."})

    user         = get_current_user()
    frontend_url = request.headers.get("Origin", "http://localhost:3000")

    result = billing_svc.create_order(
        user_id=user.id,
        course_id=course_id,
        frontend_base=frontend_url,
    )
    return jsonify(result), 201


@bp.post("/capture")
@limiter.limit(_BILLING_LIMIT)
@jwt_required_custom
def capture_order():
    data = require_json()

    # Accept ``provider_order_id`` (canonical) or ``paypal_order_id`` (legacy alias)
    provider_order_id = (
        data.get("provider_order_id")
        or data.get("paypal_order_id")
        or ""
    ).strip()

    if not provider_order_id:
        raise ValidationError(
            "Validation failed.",
            detail={"provider_order_id": "Required."},
        )

    user   = get_current_user()
    result = billing_svc.capture_order(
        user_id=user.id,
        provider_order_id=provider_order_id,    # canonical parameter name
    )
    return jsonify(result), 200
