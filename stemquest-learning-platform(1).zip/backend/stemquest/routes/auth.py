"""
STEMQuest — Auth routes

POST /api/auth/register  — public; always creates student
POST /api/auth/login     — public; returns JWT cookie + optional bearer token
POST /api/auth/logout    — authenticated
GET  /api/auth/me        — authenticated
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request, make_response
from flask_jwt_extended import create_access_token, set_access_cookies, unset_jwt_cookies

from ..services import auth as auth_svc
from ..utils.validators import require_json, validate_register, validate_login
from ..utils.auth import jwt_required_custom, get_current_user
from ..extensions import limiter

bp = Blueprint("auth", __name__)

_AUTH_LIMIT = "10 per minute"


@bp.post("/register")
@limiter.limit(_AUTH_LIMIT)
def register():
    data   = require_json()
    clean  = validate_register(data)
    user   = auth_svc.register(
        email=clean["email"],
        name=clean["name"],
        password=clean["password"],
    )
    token  = create_access_token(identity=user.id)
    resp   = make_response(
        jsonify({"message": "Registration successful.", "user": user.to_dict()}),
        201,
    )
    set_access_cookies(resp, token)
    return resp


@bp.post("/login")
@limiter.limit(_AUTH_LIMIT)
def login():
    data  = require_json()
    clean = validate_login(data)
    user  = auth_svc.login(email=clean["email"], password=clean["password"])
    token = create_access_token(identity=user.id)
    resp  = make_response(
        jsonify({"message": "Login successful.", "user": user.to_dict()}),
        200,
    )
    set_access_cookies(resp, token)
    return resp


@bp.post("/logout")
@jwt_required_custom
def logout():
    resp = make_response(jsonify({"message": "Logged out successfully."}), 200)
    unset_jwt_cookies(resp)
    return resp


@bp.get("/me")
@jwt_required_custom
def me():
    user = get_current_user()
    # Include gamification summary for student dashboard
    summary: dict | None = None
    if user.is_student():
        try:
            from ..services.gamification import get_summary
            summary = get_summary(user.id)
        except Exception:  # noqa: BLE001
            summary = None
    return jsonify({"user": user.to_dict(), "gamification": summary}), 200
