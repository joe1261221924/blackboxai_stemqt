"""
STEMQuest — Admin API

All routes require admin role.  Admin absorbs content-authoring responsibilities.
There is no teacher role.

Content:
  POST /api/admin/courses                              — create course
  PUT  /api/admin/courses/<course_id>                  — update course
  POST /api/admin/courses/<course_id>/publish          — toggle publish
  POST /api/admin/courses/<course_id>/modules          — create module
  POST /api/admin/modules/<module_id>/lessons          — create lesson
  POST /api/admin/lessons/<lesson_id>/quiz             — create quiz

Users:
  GET  /api/admin/users                               — list users (paginated)
  PUT  /api/admin/users/<user_id>/role                — update role (admin/student)
  POST /api/admin/users/<user_id>/enroll              — grant enrollment

Analytics:
  GET  /api/admin/metrics                             — platform metrics
  GET  /api/admin/analytics                           — per-course breakdown

Billing:
  GET  /api/admin/purchases                           — list purchases
  GET  /api/admin/webhook-events                      — list webhook events
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from ..services import admin as admin_svc
from ..utils.auth import admin_required
from ..utils.validators import (
    require_json,
    validate_create_course,
    validate_create_module,
    validate_create_lesson,
)
from ..utils.errors import ValidationError

bp = Blueprint("admin", __name__)


# ── Courses ────────────────────────────────────────────────────────────────

@bp.post("/courses")
@admin_required
def create_course():
    from ..utils.auth import get_current_user
    data   = require_json()
    clean  = validate_create_course(data)
    admin  = get_current_user()
    course = admin_svc.create_course(admin.id, clean)
    return jsonify({"course": course.to_dict()}), 201


@bp.put("/courses/<course_id>")
@admin_required
def update_course(course_id: str):
    data   = require_json()
    course = admin_svc.update_course(course_id, data)
    return jsonify({"course": course.to_dict()}), 200


@bp.post("/courses/<course_id>/publish")
@admin_required
def toggle_publish(course_id: str):
    course = admin_svc.publish_course(course_id)
    verb   = "published" if course.is_published else "unpublished"
    return jsonify({"message": f"Course {verb}.", "course": course.to_dict()}), 200


@bp.post("/courses/<course_id>/modules")
@admin_required
def create_module(course_id: str):
    data   = require_json()
    clean  = validate_create_module(data)
    module = admin_svc.create_module(course_id, clean)
    return jsonify({"module": module.to_dict()}), 201


@bp.post("/modules/<module_id>/lessons")
@admin_required
def create_lesson(module_id: str):
    data   = require_json()
    clean  = validate_create_lesson(data)
    lesson = admin_svc.create_lesson(module_id, clean)
    return jsonify({"lesson": lesson.to_dict()}), 201


@bp.post("/lessons/<lesson_id>/quiz")
@admin_required
def create_quiz(lesson_id: str):
    data = require_json()
    if not data.get("questions"):
        raise ValidationError("At least one question is required.", detail={"questions": "Required."})
    quiz = admin_svc.create_quiz(lesson_id, data)
    return jsonify({"quiz": quiz.to_dict(include_correct=True)}), 201


# ── Users ──────────────────────────────────────────────────────────────────

@bp.get("/users")
@admin_required
def list_users():
    page     = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 50))
    result   = admin_svc.list_users(page=page, per_page=per_page)
    return jsonify(result), 200


@bp.put("/users/<user_id>/role")
@admin_required
def update_role(user_id: str):
    data     = require_json()
    new_role = (data.get("role") or "").strip()
    if not new_role:
        raise ValidationError("Validation failed.", detail={"role": "Required."})
    user = admin_svc.update_user_role(user_id, new_role)
    return jsonify({"user": user.to_dict()}), 200


@bp.post("/users/<user_id>/enroll")
@admin_required
def grant_enrollment(user_id: str):
    from ..utils.auth import get_current_user
    data      = require_json()
    course_id = (data.get("course_id") or "").strip()
    if not course_id:
        raise ValidationError("Validation failed.", detail={"course_id": "Required."})
    admin      = get_current_user()
    enrollment = admin_svc.grant_enrollment(admin.id, user_id, course_id)
    return jsonify({"enrollment": enrollment.to_dict()}), 201


# ── Metrics / Analytics ────────────────────────────────────────────────────

@bp.get("/metrics")
@admin_required
def metrics():
    return jsonify(admin_svc.get_metrics()), 200


@bp.get("/analytics")
@admin_required
def analytics():
    return jsonify(admin_svc.get_analytics()), 200


# ── Billing ────────────────────────────────────────────────────────────────

@bp.get("/purchases")
@admin_required
def list_purchases():
    page     = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 50))
    result   = admin_svc.list_purchases(page=page, per_page=per_page)
    return jsonify(result), 200


@bp.get("/webhook-events")
@admin_required
def list_webhook_events():
    page     = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 50))
    result   = admin_svc.list_webhook_events(page=page, per_page=per_page)
    return jsonify(result), 200
