"""
STEMQuest — Gamification routes

GET  /api/gamification/me            — student: full summary (XP, streak, badges, rank)
GET  /api/gamification/leaderboard   — any authenticated user
GET  /api/gamification/my-badges     — student
POST /api/gamification/grant-points  — admin only
"""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from ..services import gamification as gami_svc
from ..utils.auth import jwt_required_custom, admin_required, get_current_user
from ..utils.helpers import new_id
from ..utils.errors import ValidationError
from ..utils.validators import require_json

bp = Blueprint("gamification", __name__)


@bp.get("/me")
@jwt_required_custom
def gamification_me():
    user = get_current_user()
    summary = gami_svc.get_summary(user.id)
    return jsonify(summary), 200


@bp.get("/leaderboard")
@jwt_required_custom
def leaderboard():
    try:
        limit = int(request.args.get("limit", 20))
        limit = max(1, min(100, limit))
    except (TypeError, ValueError):
        limit = 20
    board = gami_svc.get_leaderboard(limit=limit)
    return jsonify({"leaderboard": board, "count": len(board)}), 200


@bp.get("/my-badges")
@jwt_required_custom
def my_badges():
    user = get_current_user()
    from ..models.gamification import UserBadge, Badge
    badges = (
        UserBadge.query
        .filter_by(user_id=user.id)
        .join(Badge)
        .all()
    )
    return jsonify({"badges": [ub.to_dict() for ub in badges], "count": len(badges)}), 200


@bp.post("/grant-points")
@admin_required
def grant_points():
    """
    Admin endpoint to manually award XP to a user.
    Body: {"user_id": str, "points": int, "reason": str}
    """
    data   = require_json()
    uid    = (data.get("user_id") or "").strip()
    reason = (data.get("reason") or "Admin grant").strip()
    try:
        points = int(data.get("points") or 0)
    except (TypeError, ValueError):
        raise ValidationError("Validation failed.", detail={"points": "Must be an integer."})

    if not uid:
        raise ValidationError("Validation failed.", detail={"user_id": "Required."})
    if points <= 0:
        raise ValidationError("Validation failed.", detail={"points": "Must be greater than 0."})

    from ..models.user import User
    user = User.query.get(uid)
    if not user:
        from ..utils.errors import NotFoundError
        raise NotFoundError("User not found.")

    key = f"admin_grant_{uid}_{new_id()}"  # unique per grant (not idempotent by design)
    gami_svc.award_points_admin(uid, points, reason, key)
    return jsonify({"message": f"Awarded {points} XP to {user.name}."}), 200
