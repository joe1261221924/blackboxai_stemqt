"""
STEMQuest — Auth Service

Handles user registration, login, and /me.
Registration always creates students.  No public role escalation.
"""
from __future__ import annotations

import logging

from ..extensions import db, bcrypt
from ..models.user import User, UserRole
from ..utils.helpers import new_id, make_initials, utcnow
from ..utils.errors import ConflictError, UnauthorizedError
from . import gamification as gami

log = logging.getLogger(__name__)


def register(email: str, name: str, password: str) -> User:
    """
    Create a new student account.
    Role is always 'student' — there is no public admin registration.
    """
    existing = User.query.filter_by(email=email).first()
    if existing:
        raise ConflictError("An account with this email already exists.")

    pw_hash = bcrypt.generate_password_hash(password).decode("utf-8")
    user = User(
        id=new_id(),
        email=email,
        name=name,
        password_hash=pw_hash,
        role=UserRole.student,      # ALWAYS student on public registration
        avatar=make_initials(name),
        is_active=True,
        email_verified=False,
        created_at=utcnow(),
        updated_at=utcnow(),
    )
    db.session.add(user)
    db.session.flush()  # get the ID before gamification reads it

    # Signup bonus XP + Early Adopter badge
    gami.reward_signup(user.id)

    db.session.commit()
    log.info("New student registered: %s", email)
    return user


def login(email: str, password: str) -> User:
    """
    Validate credentials and return the User.
    Raises UnauthorizedError on invalid credentials or inactive account.
    """
    user = User.query.filter_by(email=email).first()
    if not user:
        raise UnauthorizedError("Invalid email or password.")
    if not user.is_active:
        raise UnauthorizedError("Your account has been deactivated.")
    if not bcrypt.check_password_hash(user.password_hash, password):
        raise UnauthorizedError("Invalid email or password.")
    return user
