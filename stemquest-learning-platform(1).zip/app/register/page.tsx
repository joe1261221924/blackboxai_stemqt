'use client'
// ============================================================
// STEMQuest — Register Page
// Public registration ALWAYS creates role = student.
// Never allows role escalation via this form.
// ============================================================

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import { Zap, Eye, EyeOff, AlertCircle, CheckCircle, UserPlus } from 'lucide-react'

function PasswordStrength({ password }: { password: string }) {
  const checks = [
    { label: 'At least 8 characters', met: password.length >= 8 },
    { label: 'Contains a number',     met: /\d/.test(password) },
    { label: 'Contains a letter',     met: /[a-zA-Z]/.test(password) },
  ]
  const score = checks.filter(c => c.met).length
  const barColors = ['bg-destructive', 'bg-warning', 'bg-success']
  const labels    = ['Weak', 'Fair', 'Strong']
  if (!password) return null
  return (
    <div className="mt-2">
      <div className="flex gap-1 mb-1.5">
        {[0, 1, 2].map(i => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-colors ${
              i < score ? barColors[score - 1] : 'bg-border'
            }`}
          />
        ))}
      </div>
      <p className={`text-xs font-medium ${
        score === 3 ? 'text-success' : score === 2 ? 'text-warning' : 'text-destructive'
      }`}>
        {labels[score - 1] || 'Too weak'}
      </p>
      <div className="mt-2 space-y-1">
        {checks.map(({ label, met }) => (
          <div key={label} className="flex items-center gap-1.5 text-xs">
            <CheckCircle className={`h-3 w-3 ${met ? 'text-success' : 'text-border'}`} />
            <span className={met ? 'text-muted-foreground' : 'text-muted-foreground/50'}>
              {label}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function RegisterPage() {
  const { register, isAuthenticated, session } = useAuth()
  const router = useRouter()

  const [name,     setName]     = useState('')
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [confirm,  setConfirm]  = useState('')
  const [showPw,   setShowPw]   = useState(false)
  const [error,    setError]    = useState('')
  const [loading,  setLoading]  = useState(false)

  // Role-aware redirect if already authenticated
  useEffect(() => {
    if (!isAuthenticated || !session) return
    if (session.role === 'admin') router.replace('/admin')
    else router.replace('/dashboard')
  }, [isAuthenticated, session, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!name.trim())           { setError('Full name is required.'); return }
    if (!email.trim())          { setError('Email address is required.'); return }
    if (!/\S+@\S+\.\S+/.test(email.trim())) {
      setError('Please enter a valid email address.')
      return
    }
    if (password.length < 8)    { setError('Password must be at least 8 characters.'); return }
    if (password !== confirm)   { setError('Passwords do not match.'); return }
    setLoading(true)
    const result = await register(email.trim().toLowerCase(), name.trim(), password)
    setLoading(false)
    if (result.error) setError(result.error)
    // On success, the useEffect above handles the redirect
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left panel — branding */}
      <div className="hidden lg:flex lg:w-1/2 flex-col items-center justify-center p-12 bg-card border-r border-border relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute top-1/3 left-1/3 h-72 w-72 rounded-full bg-accent/10 blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 h-48 w-48 rounded-full bg-primary/10 blur-3xl" />
        </div>
        <div className="relative z-10 max-w-sm text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="h-14 w-14 rounded-2xl bg-primary flex items-center justify-center glow-primary">
              <Zap className="h-7 w-7 text-white" />
            </div>
            <span className="text-4xl font-extrabold text-gradient-primary">STEMQuest</span>
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-4">Begin Your Journey</h2>
          <p className="text-muted-foreground leading-relaxed">
            Create your free account and start earning XP, badges, and climbing the
            leaderboard today.
          </p>
          <div className="mt-10 space-y-3 text-left">
            {[
              'Free access to all beginner courses',
              'Earn XP and badges from lesson 1',
              'Compete on the global leaderboard',
              'Track your streak and progress daily',
            ].map(item => (
              <div key={item} className="flex items-center gap-2.5">
                <CheckCircle className="h-4 w-4 text-success shrink-0" />
                <span className="text-sm text-muted-foreground">{item}</span>
              </div>
            ))}
          </div>
          <div className="mt-10 p-4 rounded-xl bg-secondary border border-border text-left">
            <p className="text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">Security note:</span>{' '}
              Public registration always creates a <strong>student</strong> account.
              Role elevation requires an admin action.
            </p>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-8">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex items-center justify-center gap-2 mb-8 lg:hidden">
            <div className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <span className="text-2xl font-extrabold text-gradient-primary">STEMQuest</span>
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold text-foreground">Create your free account</h1>
            <p className="text-muted-foreground mt-1">
              Already have an account?{' '}
              <Link href="/login" className="text-primary hover:underline font-medium">
                Sign in
              </Link>
            </p>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm mb-4">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">
                Full Name
              </label>
              <input
                type="text"
                autoComplete="name"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Alex Student"
                className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">
                Email address
              </label>
              <input
                type="email"
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Min. 8 characters"
                  className="w-full px-4 py-2.5 pr-11 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showPw ? 'Hide password' : 'Show password'}
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <PasswordStrength password={password} />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">
                Confirm Password
              </label>
              <input
                type="password"
                autoComplete="new-password"
                value={confirm}
                onChange={e => setConfirm(e.target.value)}
                placeholder="Repeat your password"
                className={`w-full px-4 py-2.5 rounded-lg bg-secondary border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-colors ${
                  confirm && confirm !== password
                    ? 'border-destructive focus:ring-destructive/50'
                    : 'border-border focus:ring-primary/50 focus:border-primary'
                }`}
              />
              {confirm && confirm !== password && (
                <p className="text-xs text-destructive mt-1">Passwords do not match</p>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 disabled:opacity-60 disabled:cursor-not-allowed transition-colors glow-primary mt-2"
            >
              {loading ? (
                <span className="h-5 w-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <UserPlus className="h-5 w-5" />
              )}
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-xs text-muted-foreground mt-6 leading-relaxed">
            By creating an account you agree to our Terms of Service. Your account
            is created as a{' '}
            <strong className="text-foreground">student</strong> role for security.
          </p>
        </div>
      </div>
    </div>
  )
}
