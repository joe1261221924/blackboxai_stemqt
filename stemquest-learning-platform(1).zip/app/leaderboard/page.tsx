'use client'
// ============================================================
// STEMQuest — Global Leaderboard
// GET /api/gamification/leaderboard?limit=50
// Top students ranked by total XP earned.
// ============================================================

import { useQuery } from '@tanstack/react-query'
import Navbar from '@/components/shared/Navbar'
import { useAuth } from '@/contexts/AuthContext'
import { gamificationApi, ApiError } from '@/lib/api'
import type { LeaderboardEntry } from '@/lib/api'
import { Trophy, Flame, Award, Zap, Crown, AlertCircle } from 'lucide-react'

const MEDAL_COLORS = ['text-gold', 'text-[#c0c0c0]', 'text-[#cd7f32]']
const MEDAL_BG     = ['bg-gold/20', 'bg-[#c0c0c0]/20', 'bg-[#cd7f32]/20']

export default function LeaderboardPage() {
  const { session } = useAuth()

  const { data: entries = [], isLoading, error } = useQuery<LeaderboardEntry[], ApiError>({
    queryKey: ['leaderboard', 50],
    queryFn:  () => gamificationApi.leaderboard(50),
    staleTime: 30_000,
  })

  const top3 = entries.slice(0, 3)
  const rest = entries.slice(3)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-10">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex p-3 rounded-xl bg-gold/20 mb-4">
            <Trophy className="h-8 w-8 text-gold" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Global Leaderboard</h1>
          <p className="text-muted-foreground">
            Top students ranked by total XP earned through lessons, quizzes, and streaks
          </p>
        </div>

        {/* Error */}
        {error && (
          <div className="flex items-center gap-3 p-4 mb-6 rounded-xl bg-destructive/10 border border-destructive/30 text-destructive">
            <AlertCircle className="h-5 w-5 shrink-0" />
            <p className="text-sm">Failed to load leaderboard. Please refresh.</p>
          </div>
        )}

        {/* Loading skeleton */}
        {isLoading && (
          <div className="space-y-2">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-14 rounded-xl bg-card border border-border animate-pulse" />
            ))}
          </div>
        )}

        {!isLoading && entries.length > 0 && (
          <>
            {/* Podium — top 3 */}
            {top3.length > 0 && (
              <div className="flex items-end justify-center gap-4 mb-10">
                {/* 2nd place */}
                {top3[1] && (
                  <div className="flex flex-col items-center gap-2 flex-1 max-w-36">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center text-sm font-bold ${MEDAL_BG[1]} ${MEDAL_COLORS[1]}`}>
                      {top3[1].avatar || top3[1].name[0]?.toUpperCase()}
                    </div>
                    <p className="text-sm font-medium text-foreground text-center truncate w-full">
                      {top3[1].name.split(' ')[0]}
                    </p>
                    <p className="text-xs text-gold font-bold">{top3[1].totalXp} XP</p>
                    <div className={`w-full h-20 rounded-t-lg flex items-center justify-center ${MEDAL_BG[1]} border border-[#c0c0c0]/30`}>
                      <span className={`text-2xl font-black ${MEDAL_COLORS[1]}`}>2</span>
                    </div>
                  </div>
                )}
                {/* 1st place */}
                {top3[0] && (
                  <div className="flex flex-col items-center gap-2 flex-1 max-w-40">
                    <Crown className="h-6 w-6 text-gold" />
                    <div className={`h-12 w-12 rounded-full flex items-center justify-center text-sm font-bold ${MEDAL_BG[0]} ${MEDAL_COLORS[0]} ring-2 ring-gold/40`}>
                      {top3[0].avatar || top3[0].name[0]?.toUpperCase()}
                    </div>
                    <p className="text-sm font-medium text-foreground text-center truncate w-full">
                      {top3[0].name.split(' ')[0]}
                    </p>
                    <p className="text-xs text-gold font-bold">{top3[0].totalXp} XP</p>
                    <div className={`w-full h-28 rounded-t-lg flex items-center justify-center ${MEDAL_BG[0]} border border-gold/30`}>
                      <span className={`text-3xl font-black ${MEDAL_COLORS[0]}`}>1</span>
                    </div>
                  </div>
                )}
                {/* 3rd place */}
                {top3[2] && (
                  <div className="flex flex-col items-center gap-2 flex-1 max-w-36">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center text-sm font-bold ${MEDAL_BG[2]} ${MEDAL_COLORS[2]}`}>
                      {top3[2].avatar || top3[2].name[0]?.toUpperCase()}
                    </div>
                    <p className="text-sm font-medium text-foreground text-center truncate w-full">
                      {top3[2].name.split(' ')[0]}
                    </p>
                    <p className="text-xs text-gold font-bold">{top3[2].totalXp} XP</p>
                    <div className={`w-full h-14 rounded-t-lg flex items-center justify-center ${MEDAL_BG[2]} border border-[#cd7f32]/30`}>
                      <span className={`text-2xl font-black ${MEDAL_COLORS[2]}`}>3</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Full table */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="p-4 border-b border-border flex items-center gap-2">
                <Zap className="h-4 w-4 text-gold" />
                <h2 className="font-semibold text-foreground">Full Rankings</h2>
                <span className="text-xs text-muted-foreground ml-auto">{entries.length} students</span>
              </div>

              <div className="divide-y divide-border">
                {entries.map(entry => {
                  const isMe  = entry.userId === session?.userId
                  const medal = entry.rank <= 3 ? MEDAL_COLORS[entry.rank - 1] : null
                  return (
                    <div
                      key={entry.userId}
                      className={`flex items-center gap-4 px-4 py-3.5 transition-colors ${
                        isMe
                          ? 'bg-primary/10 border-l-2 border-l-primary'
                          : 'hover:bg-secondary/30'
                      }`}
                    >
                      {/* Rank */}
                      <span className={`text-base font-black w-7 text-center shrink-0 ${medal ?? 'text-muted-foreground'}`}>
                        {entry.rank <= 3 ? `#${entry.rank}` : entry.rank}
                      </span>

                      {/* Avatar */}
                      <div className={`h-9 w-9 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 ${isMe ? 'bg-primary' : 'bg-[oklch(0.55_0.2_250)]'}`}>
                        {entry.avatar || entry.name[0]?.toUpperCase()}
                      </div>

                      {/* Name */}
                      <div className="flex-1 min-w-0">
                        <p className={`font-semibold truncate ${isMe ? 'text-primary' : 'text-foreground'}`}>
                          {isMe ? `${entry.name} (You)` : entry.name}
                        </p>
                      </div>

                      {/* Streak */}
                      {entry.streak > 0 && (
                        <div className="hidden sm:flex items-center gap-1 text-xs text-warning shrink-0">
                          <Flame className="h-3.5 w-3.5" />
                          {entry.streak}d
                        </div>
                      )}

                      {/* Badges */}
                      {entry.badgeCount > 0 && (
                        <div className="hidden md:flex items-center gap-1 text-xs text-muted-foreground shrink-0">
                          <Award className="h-3.5 w-3.5" />
                          {entry.badgeCount}
                        </div>
                      )}

                      {/* XP — backend field is totalXp */}
                      <div className="flex items-center gap-1 text-sm font-bold text-gold shrink-0">
                        <Zap className="h-3.5 w-3.5" />
                        {entry.totalXp}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* My rank callout */}
            {session && (
              <div className="mt-4 p-4 rounded-xl border border-primary/20 bg-primary/5 text-center">
                {(() => {
                  const me = entries.find(e => e.userId === session.userId)
                  return me ? (
                    <p className="text-sm text-muted-foreground">
                      Your current rank:{' '}
                      <strong className="text-primary">#{me.rank}</strong>
                      {' '}with{' '}
                      <strong className="text-gold">{me.totalXp} XP</strong>
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      Complete lessons to appear on the leaderboard!
                    </p>
                  )
                })()}
              </div>
            )}
          </>
        )}

        {!isLoading && entries.length === 0 && !error && (
          <div className="rounded-xl border border-border bg-card p-8 text-center text-muted-foreground text-sm">
            No ranked students yet. Complete lessons to earn XP and appear here!
          </div>
        )}
      </div>
    </div>
  )
}
