'use client'
// ============================================================
// STEMQuest — Student Dashboard
// Uses TanStack Query to fetch real backend data:
//   GET /api/gamification/me   — XP, streak, badges, rank
//   GET /api/courses           — enrolled courses with progress
//   GET /api/gamification/leaderboard — top-5 mini-board
// ============================================================

import Link from 'next/link'
import { useQuery } from '@tanstack/react-query'
import { useAuth } from '@/contexts/AuthContext'
import { gamificationApi, courseApi, ApiError } from '@/lib/api'
import type { CourseItem, LeaderboardEntry, GamificationSummary } from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import ProtectedRoute from '@/components/shared/ProtectedRoute'
import StatCard from '@/components/shared/StatCard'
import BadgeCard from '@/components/shared/BadgeCard'
import CourseCard from '@/components/shared/CourseCard'
import {
  Zap, Trophy, Flame, BookOpen,
  ArrowRight, Award, BarChart3, Target,
  TrendingUp, Star,
} from 'lucide-react'

// ── Badge icon map for BadgeCard ─────────────────────────────
const ICON_MAP: Record<string, string> = {
  Footprints: '👣', Target: '🎯', Flame: '🔥', GraduationCap: '🎓',
  Zap: '⚡', Trophy: '🏆', Rocket: '🚀', Star: '⭐', BookOpen: '📖',
}

export default function StudentDashboard() {
  const { session } = useAuth()

  // ── Gamification summary ─────────────────────────────────
  const { data: gami, isLoading: gamiLoading } = useQuery<GamificationSummary, ApiError>({
    queryKey: ['gamification', 'me'],
    queryFn:  () => gamificationApi.me(),
    enabled:  !!session,
  })

  // ── All courses (with per-user enrollment + progress) ────
  const { data: allCourses, isLoading: coursesLoading } = useQuery<CourseItem[], ApiError>({
    queryKey: ['courses'],
    queryFn:  () => courseApi.list(),
    enabled:  !!session,
  })

  const enrolledCourses: CourseItem[] = (allCourses ?? []).filter(c => c.isEnrolled)

  // ── Leaderboard (top 5) ──────────────────────────────────
  const { data: leaderboardAll } = useQuery<LeaderboardEntry[], ApiError>({
    queryKey: ['leaderboard', 5],
    queryFn:  () => gamificationApi.leaderboard(5),
    enabled:  !!session,
  })
  const leaderboard = leaderboardAll ?? []

  const loading = gamiLoading || coursesLoading

  return (
    <ProtectedRoute requiredRole="student">
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">

          {/* Welcome header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                Welcome back, {session?.name?.split(' ')[0]}
              </h1>
              <p className="text-muted-foreground mt-0.5">Here&apos;s your learning overview</p>
            </div>
            <Link
              href="/courses"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <BookOpen className="h-4 w-4" />
              Browse Courses
            </Link>
          </div>

          {/* Skeleton while loading */}
          {loading && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8 animate-pulse">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-28 rounded-xl bg-card border border-border" />
              ))}
            </div>
          )}

          {!loading && (
            <>
              {/* Stat cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <StatCard
                  label="Total XP"
                  value={gami?.totalXp ?? 0}
                  icon={Zap}
                  color="gold"
                  sublabel="Experience points"
                />
                <StatCard
                  label="Global Rank"
                  value={gami?.rank ? `#${gami.rank}` : '--'}
                  icon={Trophy}
                  color="blue"
                  sublabel="On leaderboard"
                />
                <StatCard
                  label="Day Streak"
                  value={gami?.currentStreak ?? 0}
                  icon={Flame}
                  color="red"
                  sublabel={`Best: ${gami?.longestStreak ?? 0} days`}
                />
                <StatCard
                  label="Badges Earned"
                  value={gami?.badgeCount ?? 0}
                  icon={Award}
                  color="purple"
                  sublabel="Achievements"
                />
              </div>

              <div className="grid lg:grid-cols-3 gap-6">
                {/* Left — enrolled courses + stats */}
                <div className="lg:col-span-2 space-y-6">

                  {/* Enrolled courses */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-semibold text-foreground">My Courses</h2>
                      <Link
                        href="/courses"
                        className="text-sm text-primary hover:underline flex items-center gap-1"
                      >
                        Browse more <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                    {enrolledCourses.length === 0 ? (
                      <div className="rounded-xl border border-border bg-card p-8 text-center">
                        <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                        <p className="font-medium text-foreground mb-1">No courses yet</p>
                        <p className="text-sm text-muted-foreground mb-4">
                          Enrol in a course to start learning and earning XP
                        </p>
                        <Link
                          href="/courses"
                          className="inline-flex items-center gap-1 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-primary/90 transition-colors"
                        >
                          <BookOpen className="h-4 w-4" /> Explore Courses
                        </Link>
                      </div>
                    ) : (
                      <div className="grid sm:grid-cols-2 gap-4">
                        {enrolledCourses.map(c => (
                          <CourseCard key={c.id} course={c} showProgress />
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Enrollment + completion overview */}
                  <div className="rounded-xl border border-border bg-card p-5">
                    <div className="flex items-center gap-2 mb-5">
                      <BarChart3 className="h-5 w-5 text-primary" />
                      <h2 className="text-lg font-semibold text-foreground">Learning Progress</h2>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-3 rounded-lg bg-secondary">
                        <p className="text-2xl font-bold text-foreground">{gami?.enrollments ?? 0}</p>
                        <p className="text-xs text-muted-foreground mt-1">Enrolled</p>
                      </div>
                      <div className="p-3 rounded-lg bg-primary/10">
                        <p className="text-2xl font-bold text-primary">{gami?.totalXp ?? 0}</p>
                        <p className="text-xs text-muted-foreground mt-1">Total XP</p>
                      </div>
                      <div className="p-3 rounded-lg bg-success/10">
                        <p className="text-2xl font-bold text-success">{gami?.currentStreak ?? 0}</p>
                        <p className="text-xs text-muted-foreground mt-1">Day Streak</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right sidebar */}
                <div className="space-y-5">
                  {/* Badges */}
                  <div className="rounded-xl border border-border bg-card p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Award className="h-5 w-5 text-gold" />
                        <h2 className="text-base font-semibold text-foreground">Badges</h2>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {gami?.badgeCount ?? 0} earned
                      </span>
                    </div>
                    {(gami?.badges?.length ?? 0) === 0 ? (
                      <div className="text-center py-4">
                        <Target className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-xs text-muted-foreground">
                          Complete lessons to earn badges
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {gami!.badges.slice(0, 5).map(ub => {
                          const b = ub.badge
                          if (!b) return null
                          return (
                            <BadgeCard
                              key={ub.id}
                              badge={{
                                id:          b.id,
                                name:        b.name,
                                description: b.description,
                                icon:        b.icon,
                                category:    b.category,
                                criteria:    b.criteria,
                                color:       b.color,
                                earnedAt:    ub.earnedAt,
                              }}
                              size="sm"
                            />
                          )
                        })}
                        {(gami?.badges?.length ?? 0) > 5 && (
                          <p className="text-xs text-muted-foreground text-center mt-2">
                            +{gami!.badges.length - 5} more badges
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Mini leaderboard */}
                  <div className="rounded-xl border border-border bg-card p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Trophy className="h-5 w-5 text-gold" />
                        <h2 className="text-base font-semibold text-foreground">Leaderboard</h2>
                      </div>
                      <Link
                        href="/leaderboard"
                        className="text-xs text-primary hover:underline"
                      >
                        View all
                      </Link>
                    </div>
                    <div className="space-y-2">
                      {leaderboard.length === 0 ? (
                        <p className="text-xs text-muted-foreground text-center py-3">
                          No leaderboard data yet
                        </p>
                      ) : leaderboard.map(entry => {
                        const isMe = entry.userId === session?.userId
                        return (
                          <div
                            key={entry.userId}
                            className={`flex items-center gap-2.5 p-2.5 rounded-lg ${
                              isMe
                                ? 'bg-primary/10 border border-primary/20'
                                : 'bg-secondary'
                            }`}
                          >
                            <span
                              className={`text-sm font-bold w-5 text-center shrink-0 ${
                                entry.rank <= 3 ? 'text-gold' : 'text-muted-foreground'
                              }`}
                            >
                              #{entry.rank}
                            </span>
                            <div className="h-7 w-7 rounded-full bg-primary flex items-center justify-center text-xs font-bold text-white shrink-0">
                              {entry.avatar || entry.name[0]?.toUpperCase()}
                            </div>
                            <span
                              className={`text-sm flex-1 truncate font-medium ${
                                isMe ? 'text-primary' : 'text-foreground'
                              }`}
                            >
                              {isMe ? 'You' : entry.name.split(' ')[0]}
                            </span>
                            <span className="text-xs font-bold text-gold">
                              {entry.totalXp} XP
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </ProtectedRoute>
  )
}
