'use client'
// ============================================================
// STEMQuest — Admin Dashboard
// Roles: admin only — students are redirected to /dashboard
//
// Tabs: Overview | Users | Content | Analytics | Purchases | Webhooks
//
// All data fetched from real backend via adminApi (lib/api.ts):
//   GET  /api/admin/metrics
//   GET  /api/admin/analytics
//   GET  /api/admin/users
//   GET  /api/admin/purchases
//   GET  /api/admin/webhook-events
//   POST /api/admin/courses
//   POST /api/admin/courses/:id/modules
//   POST /api/admin/modules/:id/lessons
//   POST /api/admin/lessons/:id/quiz
//   PUT  /api/admin/users/:id/role
//   POST /api/admin/users/:id/enroll
//   POST /api/admin/courses/:id/publish
// ============================================================

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/contexts/AuthContext'
import { adminApi, ApiError } from '@/lib/api'
import type {
  AdminMetrics, AdminAnalyticsRow, AdminUser,
  AdminPurchase, AdminWebhookEvent, AdminCourse,
} from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import ProtectedRoute from '@/components/shared/ProtectedRoute'
import StatCard from '@/components/shared/StatCard'
import {
  Users, BookOpen, DollarSign, Trophy,
  CheckCircle, XCircle, Search, Webhook,
  AlertCircle, BarChart3, ShieldCheck,
  Activity, Plus, ChevronRight, TrendingUp, Zap,
  GraduationCap, RefreshCcw,
} from 'lucide-react'

// ── Role colour map ──────────────────────────────────────────
const ROLE_COLORS: Record<'student' | 'admin', string> = {
  student: 'bg-primary/15 text-primary',
  admin:   'bg-gold/20 text-gold',
}
const STATUS_COLORS: Record<string, string> = {
  processed: 'bg-success/20 text-success',
  received:  'bg-warning/20 text-warning',
  failed:    'bg-destructive/20 text-destructive',
}

type Tab = 'overview' | 'users' | 'content' | 'analytics' | 'purchases' | 'webhooks'
type CreateStep = 'course' | 'module' | 'lesson' | 'quiz'

const inputCls  = 'w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm'
const selectCls = 'w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm'
const labelCls  = 'block text-sm font-medium text-foreground mb-1.5'

// ─────────────────────────────────────────────────────────────
// Create Course Wizard — multi-step form calling real API
// ─────────────────────────────────────────────────────────────
function CreateCourseWizard({ onCreated }: { onCreated: () => void }) {
  const [step, setStep] = useState<CreateStep>('course')
  const [courseId,  setCourseId]  = useState('')
  const [moduleId,  setModuleId]  = useState('')
  const [lessonId,  setLessonId]  = useState('')
  const [success,   setSuccess]   = useState('')
  const [error,     setError]     = useState('')
  const [loading,   setLoading]   = useState(false)

  // Course fields
  const [cTitle, setCTitle] = useState('')
  const [cDesc,  setCDesc]  = useState('')
  const [cSlug,  setCSlug]  = useState('')
  const [cCat,   setCCat]   = useState('Computer Science')
  const [cDiff,  setCDiff]  = useState('beginner')
  const [cFree,  setCFree]  = useState(true)
  const [cPrice, setCPrice] = useState('19.99')
  const [cHours, setCHours] = useState('2')

  // Module fields
  const [mTitle, setMTitle] = useState('')
  const [mDesc,  setMDesc]  = useState('')

  // Lesson fields
  const [lTitle,   setLTitle]   = useState('')
  const [lSummary, setLSummary] = useState('')
  const [lContent, setLContent] = useState('')
  const [lXP,      setLXP]      = useState('25')
  const [lDiff,    setLDiff]    = useState('beginner')

  // Quiz fields
  const [qTitle, setQTitle] = useState('Knowledge Check')
  const [qPass,  setQPass]  = useState('70')
  const [questions, setQuestions] = useState([
    {
      text: '',
      options: [
        { text: '', isCorrect: true  },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
      ],
    },
  ])

  // Auto-generate slug from title
  const autoSlug = (t: string) =>
    t.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')

  const handleCreateCourse = async () => {
    setError('')
    if (!cTitle.trim() || !cDesc.trim()) { setError('Title and description are required.'); return }
    const slug = cSlug.trim() || autoSlug(cTitle)
    setLoading(true)
    try {
      const course = await adminApi.createCourse({
        title: cTitle, description: cDesc, slug,
        category: cCat, difficulty: cDiff,
        isFree: cFree, price: parseFloat(cPrice) || 0,
        estimatedHours: parseFloat(cHours) || 2,
      })
      setCourseId(course.id)
      setSuccess(`Course "${course.title}" created.`)
      setStep('module')
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to create course.')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateModule = async () => {
    setError('')
    if (!mTitle.trim()) { setError('Module title is required.'); return }
    setLoading(true)
    try {
      const mod = await adminApi.createModule(courseId, mTitle, mDesc)
      setModuleId(mod.id)
      setSuccess(`Module "${mTitle}" added.`)
      setStep('lesson')
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to create module.')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateLesson = async () => {
    setError('')
    if (!lTitle.trim() || !lContent.trim()) { setError('Title and content are required.'); return }
    setLoading(true)
    try {
      const les = await adminApi.createLesson(moduleId, {
        title: lTitle, summary: lSummary, content: lContent,
        difficulty: lDiff, xpReward: parseInt(lXP) || 25,
      })
      setLessonId(les.id)
      setSuccess(`Lesson "${lTitle}" added.`)
      setStep('quiz')
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to create lesson.')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateQuiz = async () => {
    setError('')
    if (!qTitle.trim()) { setError('Quiz title is required.'); return }
    const validQs = questions.filter(q => q.text.trim() && q.options.some(o => o.text.trim()))
    if (validQs.length === 0) { setError('Add at least one question with options.'); return }
    setLoading(true)
    try {
      await adminApi.createQuiz(lessonId, {
        title: qTitle,
        passingScore: parseInt(qPass) || 70,
        questions: validQs.map(q => ({
          text: q.text,
          options: q.options.filter(o => o.text.trim()).map(o => ({
            text: o.text, isCorrect: o.isCorrect,
          })),
        })),
      })
      setSuccess('Quiz created. Course setup complete!')
      onCreated()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to create quiz.')
    } finally {
      setLoading(false)
    }
  }

  const updateQ = (qi: number, text: string) =>
    setQuestions(prev => prev.map((q, i) => i === qi ? { ...q, text } : q))
  const updateOpt = (qi: number, oi: number, text: string) =>
    setQuestions(prev =>
      prev.map((q, i) =>
        i === qi ? { ...q, options: q.options.map((o, j) => j === oi ? { ...o, text } : o) } : q
      )
    )
  const setCorrect = (qi: number, oi: number) =>
    setQuestions(prev =>
      prev.map((q, i) =>
        i === qi ? { ...q, options: q.options.map((o, j) => ({ ...o, isCorrect: j === oi })) } : q
      )
    )
  const addQuestion = () =>
    setQuestions(prev => [
      ...prev,
      { text: '', options: [
        { text: '', isCorrect: true  },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
      ] },
    ])

  const stepLabels: CreateStep[] = ['course', 'module', 'lesson', 'quiz']
  const stepIdx = stepLabels.indexOf(step)

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
        {stepLabels.map((s, i) => (
          <div key={s} className="flex items-center gap-2 shrink-0">
            <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold border-2 ${
              i < stepIdx  ? 'bg-success border-success text-white' :
              i === stepIdx ? 'bg-primary border-primary text-white' :
                             'border-border text-muted-foreground'
            }`}>
              {i < stepIdx ? <CheckCircle className="h-4 w-4" /> : i + 1}
            </div>
            <span className={`text-sm capitalize ${i === stepIdx ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
              {s}
            </span>
            {i < stepLabels.length - 1 && <ChevronRight className="h-4 w-4 text-border" />}
          </div>
        ))}
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm mb-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}
      {success && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-success/10 border border-success/30 text-success text-sm mb-4">
          <CheckCircle className="h-4 w-4 shrink-0" />
          {success}
        </div>
      )}

      {/* ── STEP: Course ────────────────────────────────── */}
      {step === 'course' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Create Course</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className={labelCls}>Title *</label>
              <input className={inputCls} value={cTitle} onChange={e => { setCTitle(e.target.value); setCSlug(autoSlug(e.target.value)) }} placeholder="Intro to Python" />
            </div>
            <div className="sm:col-span-2">
              <label className={labelCls}>Description *</label>
              <textarea className={inputCls} rows={3} value={cDesc} onChange={e => setCDesc(e.target.value)} placeholder="What students will learn..." />
            </div>
            <div>
              <label className={labelCls}>Slug (auto-generated)</label>
              <input className={inputCls} value={cSlug} onChange={e => setCSlug(e.target.value)} placeholder="intro-to-python" />
            </div>
            <div>
              <label className={labelCls}>Category</label>
              <select className={selectCls} value={cCat} onChange={e => setCCat(e.target.value)}>
                {['Computer Science', 'Mathematics', 'Physics', 'Engineering'].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>Difficulty</label>
              <select className={selectCls} value={cDiff} onChange={e => setCDiff(e.target.value)}>
                {['beginner', 'intermediate', 'advanced'].map(d => <option key={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>Estimated Hours</label>
              <input type="number" className={inputCls} value={cHours} onChange={e => setCHours(e.target.value)} min="0" step="0.5" />
            </div>
            <div>
              <label className={labelCls}>Access</label>
              <select className={selectCls} value={cFree ? 'free' : 'premium'} onChange={e => setCFree(e.target.value === 'free')}>
                <option value="free">Free</option>
                <option value="premium">Premium</option>
              </select>
            </div>
            {!cFree && (
              <div>
                <label className={labelCls}>Price (USD)</label>
                <input type="number" className={inputCls} value={cPrice} onChange={e => setCPrice(e.target.value)} min="0" step="0.01" />
              </div>
            )}
          </div>
          <button
            onClick={handleCreateCourse}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
          >
            {loading ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> : <Plus className="h-4 w-4" />}
            Create Course
          </button>
        </div>
      )}

      {/* ── STEP: Module ────────────────────────────────── */}
      {step === 'module' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Add Module</h3>
          <div>
            <label className={labelCls}>Module Title *</label>
            <input className={inputCls} value={mTitle} onChange={e => setMTitle(e.target.value)} placeholder="Module 1: Getting Started" />
          </div>
          <div>
            <label className={labelCls}>Description</label>
            <textarea className={inputCls} rows={2} value={mDesc} onChange={e => setMDesc(e.target.value)} placeholder="What this module covers..." />
          </div>
          <button
            onClick={handleCreateModule}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
          >
            {loading ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> : <Plus className="h-4 w-4" />}
            Add Module
          </button>
        </div>
      )}

      {/* ── STEP: Lesson ────────────────────────────────── */}
      {step === 'lesson' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Add Lesson</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className={labelCls}>Lesson Title *</label>
              <input className={inputCls} value={lTitle} onChange={e => setLTitle(e.target.value)} placeholder="Introduction to Variables" />
            </div>
            <div className="sm:col-span-2">
              <label className={labelCls}>Summary</label>
              <input className={inputCls} value={lSummary} onChange={e => setLSummary(e.target.value)} placeholder="Short description shown in the course outline" />
            </div>
            <div className="sm:col-span-2">
              <label className={labelCls}>Content (Markdown) *</label>
              <textarea className={`${inputCls} font-mono`} rows={8} value={lContent} onChange={e => setLContent(e.target.value)} placeholder="## Introduction&#10;&#10;In this lesson we will..." />
            </div>
            <div>
              <label className={labelCls}>Difficulty</label>
              <select className={selectCls} value={lDiff} onChange={e => setLDiff(e.target.value)}>
                {['beginner', 'intermediate', 'advanced'].map(d => <option key={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>XP Reward</label>
              <input type="number" className={inputCls} value={lXP} onChange={e => setLXP(e.target.value)} min="1" max="500" />
            </div>
          </div>
          <button
            onClick={handleCreateLesson}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
          >
            {loading ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> : <Plus className="h-4 w-4" />}
            Add Lesson
          </button>
        </div>
      )}

      {/* ── STEP: Quiz ──────────────────────────────────── */}
      {step === 'quiz' && (
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Create Quiz</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Quiz Title</label>
              <input className={inputCls} value={qTitle} onChange={e => setQTitle(e.target.value)} placeholder="Knowledge Check" />
            </div>
            <div>
              <label className={labelCls}>Passing Score (%)</label>
              <input type="number" className={inputCls} value={qPass} onChange={e => setQPass(e.target.value)} min="50" max="100" />
            </div>
          </div>

          {/* Questions */}
          <div className="space-y-4">
            {questions.map((q, qi) => (
              <div key={qi} className="p-4 rounded-xl border border-border bg-secondary space-y-3">
                <div>
                  <label className={labelCls}>Question {qi + 1}</label>
                  <input className={inputCls} value={q.text} onChange={e => updateQ(qi, e.target.value)} placeholder="Enter your question..." />
                </div>
                <div className="space-y-2">
                  {q.options.map((opt, oi) => (
                    <div key={oi} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name={`correct-${qi}`}
                        checked={opt.isCorrect}
                        onChange={() => setCorrect(qi, oi)}
                        className="accent-primary shrink-0"
                        title={`Mark option ${String.fromCharCode(65 + oi)} as correct`}
                      />
                      <input
                        className={`${inputCls} flex-1`}
                        value={opt.text}
                        onChange={e => updateOpt(qi, oi, e.target.value)}
                        placeholder={`Option ${String.fromCharCode(65 + oi)}`}
                      />
                      {opt.isCorrect && (
                        <CheckCircle className="h-4 w-4 text-success shrink-0" />
                      )}
                    </div>
                  ))}
                  <p className="text-xs text-muted-foreground">Select the radio button next to the correct answer</p>
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={addQuestion}
              className="flex items-center gap-1.5 text-xs text-primary hover:underline"
            >
              <Plus className="h-3.5 w-3.5" />
              Add Another Question
            </button>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleCreateQuiz}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
            >
              {loading ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> : <CheckCircle className="h-4 w-4" />}
              Create Quiz
            </button>
            <button
              onClick={onCreated}
              className="px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
            >
              Skip Quiz
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────
// Main Admin Page
// ─────────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const { session } = useAuth()
  const queryClient = useQueryClient()
  const [activeTab,     setActiveTab]     = useState<Tab>('overview')
  const [showWizard,    setShowWizard]    = useState(false)
  const [userSearch,    setUserSearch]    = useState('')
  const [grantUserId,   setGrantUserId]   = useState('')
  const [grantCourseId, setGrantCourseId] = useState('')
  const [grantMsg,      setGrantMsg]      = useState('')

  // ── Data queries ─────────────────────────────────────────
  const { data: metrics, isLoading: metricsLoading } = useQuery<AdminMetrics, ApiError>({
    queryKey: ['admin', 'metrics'],
    queryFn:  () => adminApi.metrics(),
    enabled:  !!session,
  })

  const { data: analytics = [], isLoading: analyticsLoading } = useQuery<AdminAnalyticsRow[], ApiError>({
    queryKey: ['admin', 'analytics'],
    queryFn:  () => adminApi.analytics(),
    enabled:  activeTab === 'analytics' && !!session,
  })

  const { data: usersData, isLoading: usersLoading } = useQuery<{
    items: AdminUser[]; total: number; pages: number; page: number
  }, ApiError>({
    queryKey: ['admin', 'users'],
    queryFn:  () => adminApi.listUsers(1, 100),
    enabled:  activeTab === 'users' && !!session,
  })

  const { data: purchasesData, isLoading: purchasesLoading } = useQuery<{
    items: AdminPurchase[]; total: number
  }, ApiError>({
    queryKey: ['admin', 'purchases'],
    queryFn:  () => adminApi.listPurchases(1),
    enabled:  activeTab === 'purchases' && !!session,
  })

  const { data: webhooksData, isLoading: webhooksLoading } = useQuery<{
    items: AdminWebhookEvent[]; total: number
  }, ApiError>({
    queryKey: ['admin', 'webhooks'],
    queryFn:  () => adminApi.listWebhookEvents(1),
    enabled:  activeTab === 'webhooks' && !!session,
  })

  const { data: coursesData = [] } = useQuery<AdminCourse[], ApiError>({
    queryKey: ['admin', 'courses'],
    queryFn:  () => adminApi.listCourses(),
    enabled:  !!session,
  })

  // ── Mutations ────────────────────────────────────────────
  const { mutate: updateRole, isPending: updatingRole } = useMutation<
    AdminUser, ApiError, { userId: string; role: 'student' | 'admin' }
  >({
    mutationFn: ({ userId, role }) => adminApi.updateUserRole(userId, role),
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['admin', 'users'] }),
  })

  const { mutate: togglePublish, isPending: publishing } = useMutation<
    AdminCourse, ApiError, string
  >({
    mutationFn: (courseId) => adminApi.togglePublish(courseId),
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['admin', 'courses'] }),
  })

  const { mutate: grantEnroll, isPending: granting } = useMutation<
    void, ApiError, { userId: string; courseId: string }
  >({
    mutationFn: ({ userId, courseId }) => adminApi.grantEnrollment(userId, courseId),
    onSuccess:  () => {
      setGrantMsg('Enrollment granted successfully.')
      setGrantUserId('')
      setGrantCourseId('')
    },
    onError:    (err) => setGrantMsg(`Error: ${err.message}`),
  })

  // ── Derived data ─────────────────────────────────────────
  const allUsers     = usersData?.items ?? []
  const filteredUsers = userSearch
    ? allUsers.filter(u =>
        u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
        u.email.toLowerCase().includes(userSearch.toLowerCase())
      )
    : allUsers

  // ── Tab config ───────────────────────────────────────────
  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'overview',   label: 'Overview',   icon: BarChart3    },
    { id: 'users',      label: 'Users',      icon: Users        },
    { id: 'content',    label: 'Content',    icon: BookOpen     },
    { id: 'analytics',  label: 'Analytics',  icon: TrendingUp   },
    { id: 'purchases',  label: 'Purchases',  icon: DollarSign   },
    { id: 'webhooks',   label: 'Webhooks',   icon: Webhook      },
  ]

  return (
    <ProtectedRoute requiredRole="admin">
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">

          {/* Page header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="h-5 w-5 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">Admin Dashboard</h1>
              </div>
              <p className="text-muted-foreground text-sm">
                Welcome, {session?.name}. Manage STEMQuest content and users.
              </p>
            </div>
            <button
              onClick={() => queryClient.invalidateQueries()}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
            >
              <RefreshCcw className="h-3.5 w-3.5" />
              Refresh
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mb-8 overflow-x-auto pb-1">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === id
                    ? 'bg-primary/15 text-primary'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </div>

          {/* ── OVERVIEW tab ──────────────────────────────── */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {metricsLoading ? (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
                  {[...Array(8)].map((_, i) => (
                    <div key={i} className="h-28 rounded-xl bg-card border border-border" />
                  ))}
                </div>
              ) : metrics ? (
                <>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <StatCard label="Total Users"       value={metrics.users.total}              icon={Users}        color="blue" />
                    <StatCard label="Students"          value={metrics.users.students}           icon={GraduationCap} color="blue" />
                    <StatCard label="Published Courses" value={metrics.courses.published}        icon={BookOpen}     color="green" />
                    <StatCard label="Total Enrollments" value={metrics.enrollments.total}        icon={Activity}     color="purple" />
                    <StatCard label="Revenue (USD)"     value={`$${metrics.revenue.totalUsd.toFixed(2)}`} icon={DollarSign} color="gold" sublabel="Total" />
                    <StatCard label="Quiz Attempts"     value={metrics.quizzes.totalAttempts}    icon={Trophy}       color="red" />
                    <StatCard label="Pass Rate"         value={`${metrics.quizzes.passRatePct.toFixed(1)}%`} icon={CheckCircle} color="green" sublabel="Quizzes" />
                    <StatCard label="Completions"       value={metrics.enrollments.completions}  icon={Zap}          color="gold" />
                  </div>

                  {/* Course list with publish toggle */}
                  <div className="rounded-xl border border-border bg-card overflow-hidden">
                    <div className="p-4 border-b border-border flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4 text-primary" />
                        <h2 className="font-semibold text-foreground">Courses</h2>
                      </div>
                      <span className="text-xs text-muted-foreground">{coursesData.length} total</span>
                    </div>
                    {coursesData.length === 0 ? (
                      <p className="p-6 text-center text-sm text-muted-foreground">No courses yet. Create one in the Content tab.</p>
                    ) : (
                      <div className="divide-y divide-border">
                        {coursesData.map(c => (
                          <div key={c.id} className="flex items-center justify-between px-4 py-3 gap-3">
                            <div className="min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">{c.title}</p>
                              <div className="flex gap-2 mt-0.5">
                                <span className="text-xs text-muted-foreground capitalize">{c.difficulty}</span>
                                <span className="text-xs text-muted-foreground">·</span>
                                <span className="text-xs text-muted-foreground">{c.isFree ? 'Free' : c.price > 0 ? `$${c.price.toFixed(2)}` : 'Premium'}</span>
                              </div>
                            </div>
                            <button
                              onClick={() => togglePublish(c.id)}
                              disabled={publishing}
                              className={`shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                                c.isPublished
                                  ? 'bg-success/20 text-success hover:bg-destructive/20 hover:text-destructive'
                                  : 'bg-secondary text-muted-foreground hover:bg-primary/15 hover:text-primary'
                              }`}
                            >
                              {c.isPublished ? <CheckCircle className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                              {c.isPublished ? 'Published' : 'Draft'}
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              ) : null}
            </div>
          )}

          {/* ── USERS tab ─────────────────────────────────── */}
          {activeTab === 'users' && (
            <div className="space-y-6">
              {/* Search */}
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={e => setUserSearch(e.target.value)}
                  placeholder="Search by name or email..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm"
                />
              </div>

              {/* Grant Enrollment */}
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <GraduationCap className="h-4 w-4 text-primary" />
                  Grant Enrollment
                </h3>
                {grantMsg && (
                  <div className={`flex items-center gap-2 p-3 rounded-lg text-sm mb-4 ${
                    grantMsg.startsWith('Error')
                      ? 'bg-destructive/10 border border-destructive/30 text-destructive'
                      : 'bg-success/10 border border-success/30 text-success'
                  }`}>
                    {grantMsg.startsWith('Error') ? <AlertCircle className="h-4 w-4 shrink-0" /> : <CheckCircle className="h-4 w-4 shrink-0" />}
                    {grantMsg}
                  </div>
                )}
                <div className="flex flex-wrap gap-3 items-end">
                  <div>
                    <label className={labelCls}>User</label>
                    <select className={selectCls} style={{ minWidth: '180px' }} value={grantUserId} onChange={e => setGrantUserId(e.target.value)}>
                      <option value="">Select user...</option>
                      {allUsers.filter(u => u.role === 'student').map(u => (
                        <option key={u.id} value={u.id}>{u.name} ({u.email})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className={labelCls}>Course</label>
                    <select className={selectCls} style={{ minWidth: '200px' }} value={grantCourseId} onChange={e => setGrantCourseId(e.target.value)}>
                      <option value="">Select course...</option>
                      {coursesData.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.title} {c.isFree ? '(Free)' : c.price > 0 ? `($${c.price.toFixed(2)})` : '(Premium)'}
                          {!c.isPublished ? ' [Draft]' : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                  <button
                    onClick={() => {
                      if (!grantUserId || !grantCourseId) { setGrantMsg('Error: Select a user and course.'); return }
                      setGrantMsg('')
                      grantEnroll({ userId: grantUserId, courseId: grantCourseId })
                    }}
                    disabled={granting}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
                  >
                    {granting ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> : <GraduationCap className="h-4 w-4" />}
                    Grant
                  </button>
                </div>
              </div>

              {/* User table */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="p-4 border-b border-border flex items-center gap-2">
                  <Users className="h-4 w-4 text-primary" />
                  <h2 className="font-semibold text-foreground">
                    Users ({filteredUsers.length}{userSearch ? ` of ${allUsers.length}` : ''})
                  </h2>
                </div>
                {usersLoading ? (
                  <div className="p-6 space-y-2 animate-pulse">
                    {[...Array(5)].map((_, i) => <div key={i} className="h-12 rounded-lg bg-secondary" />)}
                  </div>
                ) : filteredUsers.length === 0 ? (
                  <p className="p-6 text-center text-sm text-muted-foreground">No users found.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-secondary/50">
                        <tr>
                          {['Name', 'Email', 'Role', 'Joined', 'Actions'].map(h => (
                            <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {filteredUsers.map(u => (
                          <tr key={u.id} className="hover:bg-secondary/30 transition-colors">
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-xs font-bold text-white shrink-0">
                                  {u.avatar || u.name[0]?.toUpperCase()}
                                </div>
                                <span className="text-sm font-medium text-foreground truncate max-w-32">{u.name}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm text-muted-foreground truncate max-w-48">{u.email}</td>
                            <td className="px-4 py-3">
                              <span className={`badge-pill text-xs capitalize ${ROLE_COLORS[u.role]}`}>{u.role}</span>
                            </td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                              {new Date(u.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-3">
                              <button
                                onClick={() => updateRole({
                                  userId: u.id,
                                  role: u.role === 'admin' ? 'student' : 'admin',
                                })}
                                disabled={updatingRole || u.id === session?.userId}
                                className="text-xs text-primary hover:underline disabled:opacity-40 disabled:cursor-not-allowed"
                              >
                                Make {u.role === 'admin' ? 'Student' : 'Admin'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── CONTENT tab ───────────────────────────────── */}
          {activeTab === 'content' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-foreground">Content Management</h2>
                  <p className="text-sm text-muted-foreground mt-1">
                    Create courses, modules, lessons, and quizzes for students.
                  </p>
                </div>
                {!showWizard && (
                  <button
                    onClick={() => setShowWizard(true)}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                    New Course
                  </button>
                )}
              </div>

              {showWizard && (
                <CreateCourseWizard
                  onCreated={() => {
                    setShowWizard(false)
                    queryClient.invalidateQueries({ queryKey: ['admin', 'courses'] })
                    queryClient.invalidateQueries({ queryKey: ['admin', 'metrics'] })
                  }}
                />
              )}

              {/* Course list */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="p-4 border-b border-border flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-primary" />
                  <h3 className="font-semibold text-foreground">All Courses ({coursesData.length})</h3>
                </div>
                {coursesData.length === 0 ? (
                  <p className="p-6 text-center text-sm text-muted-foreground">
                    No courses yet. Use the wizard above to create your first course.
                  </p>
                ) : (
                  <div className="divide-y divide-border">
                    {coursesData.map(c => (
                      <div key={c.id} className="flex items-center justify-between px-4 py-3.5 gap-4">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-foreground truncate">{c.title}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {[c.category, c.difficulty, `${c.totalLessons} lessons`, c.isFree ? 'Free' : c.price > 0 ? `$${c.price.toFixed(2)}` : 'Premium'].filter(Boolean).join(' · ')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`badge-pill text-xs ${c.isPublished ? 'bg-success/20 text-success' : 'bg-secondary text-muted-foreground'}`}>
                            {c.isPublished ? 'Published' : 'Draft'}
                          </span>
                          <button
                            onClick={() => togglePublish(c.id)}
                            disabled={publishing}
                            className="text-xs text-primary hover:underline disabled:opacity-40"
                          >
                            {c.isPublished ? 'Unpublish' : 'Publish'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── ANALYTICS tab ─────────────────────────────── */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-foreground">Course Analytics</h2>
              {analyticsLoading ? (
                <div className="space-y-2 animate-pulse">
                  {[...Array(4)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-card border border-border" />)}
                </div>
              ) : analytics.length === 0 ? (
                <p className="p-6 text-center text-sm text-muted-foreground">No analytics data available yet.</p>
              ) : (
                <div className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-secondary/50">
                        <tr>
                          {['Course', 'Status', 'Enrolled', 'Completed', 'Revenue'].map(h => (
                            <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {analytics.map(row => (
                          <tr key={row.courseId} className="hover:bg-secondary/30 transition-colors">
                            <td className="px-4 py-3 text-sm font-medium text-foreground max-w-56 truncate">{row.courseTitle}</td>
                            <td className="px-4 py-3">
                              <span className={`badge-pill text-xs ${row.isPublished ? 'bg-success/20 text-success' : 'bg-secondary text-muted-foreground'}`}>
                                {row.isPublished ? 'Published' : 'Draft'}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm text-muted-foreground">{row.enrolled}</td>
                            <td className="px-4 py-3 text-sm text-muted-foreground">{row.completed}</td>
                            <td className="px-4 py-3 text-sm font-medium text-success">
                              {row.isFree ? 'Free' : `$${row.revenueUsd.toFixed(2)}`}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── PURCHASES tab ─────────────────────────────── */}
          {activeTab === 'purchases' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">
                  Purchases ({purchasesData?.total ?? 0})
                </h2>
              </div>
              {purchasesLoading ? (
                <div className="space-y-2 animate-pulse">
                  {[...Array(5)].map((_, i) => <div key={i} className="h-14 rounded-xl bg-card border border-border" />)}
                </div>
              ) : (purchasesData?.items ?? []).length === 0 ? (
                <p className="p-6 text-center text-sm text-muted-foreground">No purchases yet.</p>
              ) : (
                <div className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-secondary/50">
                        <tr>
                          {['ID', 'Amount', 'Status', 'PayPal Order', 'Date'].map(h => (
                            <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {(purchasesData?.items ?? []).map(p => (
                          <tr key={p.id} className="hover:bg-secondary/30 transition-colors">
                            <td className="px-4 py-3 text-xs text-muted-foreground font-mono truncate max-w-24">{p.id.slice(0, 8)}…</td>
                            <td className="px-4 py-3 text-sm font-bold text-success">${p.amount.toFixed(2)} {p.currency}</td>
                            <td className="px-4 py-3">
                              <span className={`badge-pill text-xs ${STATUS_COLORS[p.status] ?? 'bg-secondary text-muted-foreground'}`}>
                                {p.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-xs text-muted-foreground font-mono truncate max-w-32">{p.paypalOrderId.slice(0, 12)}…</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                              {new Date(p.createdAt).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── WEBHOOKS tab ──────────────────────────────── */}
          {activeTab === 'webhooks' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Webhook className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">
                  Webhook Events ({webhooksData?.total ?? 0})
                </h2>
              </div>
              {webhooksLoading ? (
                <div className="space-y-2 animate-pulse">
                  {[...Array(5)].map((_, i) => <div key={i} className="h-14 rounded-xl bg-card border border-border" />)}
                </div>
              ) : (webhooksData?.items ?? []).length === 0 ? (
                <p className="p-6 text-center text-sm text-muted-foreground">No webhook events yet.</p>
              ) : (
                <div className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-secondary/50">
                        <tr>
                          {['Provider', 'Event Type', 'Status', 'Received', 'Processed'].map(h => (
                            <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {(webhooksData?.items ?? []).map(w => (
                          <tr key={w.id} className="hover:bg-secondary/30 transition-colors">
                            <td className="px-4 py-3 text-sm text-muted-foreground capitalize">{w.provider}</td>
                            <td className="px-4 py-3 text-xs font-mono text-foreground">{w.eventType}</td>
                            <td className="px-4 py-3">
                              <span className={`badge-pill text-xs ${STATUS_COLORS[w.status] ?? 'bg-secondary text-muted-foreground'}`}>
                                {w.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                              {new Date(w.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                              {w.processedAt ? new Date(w.processedAt).toLocaleDateString() : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </ProtectedRoute>
  )
}
