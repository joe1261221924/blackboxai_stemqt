'use client'
// ============================================================
// STEMQuest — Quiz Page
// GET  /api/courses/:courseId/lessons/:lessonId/quiz
// POST /api/courses/:courseId/lessons/:lessonId/quiz/submit
// Uses TanStack Query; framer-motion for result animations.
// ============================================================

import { useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/contexts/AuthContext'
import { courseApi, ApiError } from '@/lib/api'
import type { QuizItem, QuizSubmitResult } from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import ProtectedRoute from '@/components/shared/ProtectedRoute'
import {
  Trophy, CheckCircle, XCircle, ArrowRight, ArrowLeft,
  Zap, AlertCircle, RotateCcw, ChevronRight,
} from 'lucide-react'

// Map Lucide icon name strings to emoji
const BADGE_EMOJI: Record<string, string> = {
  Footprints: '👣', Target: '🎯', Flame: '🔥', GraduationCap: '🎓',
  Zap: '⚡', Trophy: '🏆', Rocket: '🚀', Star: '⭐', BookOpen: '📖',
}

const recStyles: Record<string, { bg: string; text: string; border: string; icon: React.ElementType }> = {
  review:   { bg: 'bg-warning/10',   text: 'text-warning',   border: 'border-warning/30',   icon: RotateCcw },
  next:     { bg: 'bg-primary/10',   text: 'text-primary',   border: 'border-primary/30',   icon: ArrowRight },
  advanced: { bg: 'bg-success/10',   text: 'text-success',   border: 'border-success/30',   icon: Trophy },
}

// ── Skeleton ──────────────────────────────────────────────────
function QuizSkeleton() {
  return (
    <div className="min-h-screen bg-background animate-pulse">
      <div className="mx-auto max-w-2xl px-4 py-12 space-y-4">
        <div className="h-8 w-1/2 rounded bg-secondary" />
        <div className="h-4 w-1/3 rounded bg-secondary" />
        <div className="h-48 rounded-xl bg-secondary" />
      </div>
    </div>
  )
}

export default function QuizPage() {
  const { slug, lessonId } = useParams<{ slug: string; lessonId: string }>()
  const { session } = useAuth()
  const queryClient = useQueryClient()

  const [answers,    setAnswers]    = useState<Record<string, string>>({})
  const [result,     setResult]     = useState<QuizSubmitResult | null>(null)
  const [currentQ,   setCurrentQ]   = useState(0)
  const [showReview, setShowReview] = useState(false)

  // ── Load quiz ────────────────────────────────────────────────
  // We need the courseId (not slug) for the API. Fetch course first.
  const { data: course } = useQuery({
    queryKey: ['course', slug],
    queryFn:  () => courseApi.detail(slug),
    enabled:  !!session,
  })

  const { data: quiz, isLoading, error: quizError } = useQuery<QuizItem, ApiError>({
    queryKey: ['quiz', slug, lessonId],
    queryFn:  () => courseApi.getQuiz(course!.id, lessonId),
    enabled:  !!course && !!session,
  })

  // ── Submit quiz mutation ──────────────────────────────────────
  const { mutate: submitQuiz, isPending: submitting } = useMutation<
    QuizSubmitResult, ApiError, Record<string, string>
  >({
    mutationFn: (ans) => courseApi.submitQuiz(course!.id, lessonId, ans),
    onSuccess:  (data) => {
      setResult(data)
      // Refresh quiz (to update bestAttempt), gamification, and course data
      queryClient.invalidateQueries({ queryKey: ['quiz', slug, lessonId] })
      queryClient.invalidateQueries({ queryKey: ['gamification'] })
      queryClient.invalidateQueries({ queryKey: ['course', slug] })
    },
  })

  const handleAnswer = (questionId: string, optionId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionId }))
  }

  const handleSubmit = () => {
    if (!quiz) return
    submitQuiz(answers)
  }

  const handleRetry = () => {
    setAnswers({})
    setResult(null)
    setCurrentQ(0)
    setShowReview(false)
  }

  // ── Loading ──────────────────────────────────────────────────
  if (isLoading || !course) return <QuizSkeleton />

  // ── No quiz ──────────────────────────────────────────────────
  if (quizError || !quiz) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background">
          <Navbar />
          <div className="flex flex-col items-center justify-center py-32 gap-4">
            <AlertCircle className="h-12 w-12 text-muted-foreground" />
            <p className="text-foreground font-medium">No quiz for this lesson</p>
            <Link
              href={`/courses/${slug}/lessons/${lessonId}`}
              className="text-primary hover:underline flex items-center gap-1"
            >
              <ArrowLeft className="h-4 w-4" /> Back to lesson
            </Link>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  const questions  = quiz.questions
  const allAnswered = questions.every(q => answers[q.id])
  const progress   = (Object.keys(answers).length / Math.max(questions.length, 1)) * 100

  // ── Results screen ────────────────────────────────────────────
  if (result) {
    const { attempt, recommendationText, xpAwarded, newBadges } = result
    const rec     = recStyles[attempt.recommendation] || recStyles.next
    const RecIcon = rec.icon

    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background">
          <Navbar />
          <div className="mx-auto max-w-2xl px-4 py-12">

            {/* Score card */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: 'easeOut' }}
            >
              <div className={`rounded-2xl border p-8 mb-6 text-center ${
                attempt.passed
                  ? 'bg-success/10 border-success/30'
                  : 'bg-destructive/10 border-destructive/30'
              }`}>
                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.15, type: 'spring', stiffness: 260, damping: 20 }}
                  className="flex justify-center mb-4"
                >
                  {attempt.passed
                    ? <CheckCircle className="h-16 w-16 text-success" />
                    : <XCircle className="h-16 w-16 text-destructive" />
                  }
                </motion.div>

                <h1 className="text-3xl font-bold text-foreground mb-2">
                  {attempt.passed
                    ? (attempt.perfectScore ? 'Perfect Score!' : 'Quiz Passed!')
                    : 'Quiz Failed'}
                </h1>

                <motion.div
                  initial={{ scale: 0.7, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.25, type: 'spring', stiffness: 200, damping: 18 }}
                  className="text-6xl font-extrabold my-4 text-gradient-primary"
                >
                  {attempt.score}%
                </motion.div>

                <p className="text-muted-foreground text-sm">
                  Passing score: {quiz.passingScore}% &middot;{' '}
                  {attempt.passed ? 'You passed!' : 'Keep trying!'}
                </p>

                {xpAwarded > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-full bg-gold/20 text-gold font-bold text-sm"
                  >
                    <Zap className="h-4 w-4" />
                    +{xpAwarded} XP earned
                  </motion.div>
                )}

                {newBadges.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.55 }}
                    className="mt-3 flex flex-wrap justify-center gap-2"
                  >
                    {newBadges.map(b => (
                      <span key={b.id} className="badge-pill bg-gold/20 text-gold">
                        {BADGE_EMOJI[b.icon] ?? '🏅'} {b.name} unlocked!
                      </span>
                    ))}
                  </motion.div>
                )}
              </div>
            </motion.div>

            {/* Adaptive recommendation */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35, duration: 0.4 }}
              className={`rounded-xl border p-5 mb-6 ${rec.bg} ${rec.border}`}
            >
              <div className="flex items-start gap-3">
                <RecIcon className={`h-5 w-5 ${rec.text} shrink-0 mt-0.5`} />
                <div>
                  <p className={`font-semibold ${rec.text} mb-1`}>
                    {attempt.recommendation === 'review'
                      ? 'Recommendation: Review Content'
                      : attempt.recommendation === 'advanced'
                      ? 'Recommendation: Try Advanced Material'
                      : 'Recommendation: Continue to Next Lesson'}
                  </p>
                  <p className="text-sm text-muted-foreground">{recommendationText}</p>
                </div>
              </div>
            </motion.div>

            {/* Review answers toggle */}
            <button
              onClick={() => setShowReview(!showReview)}
              className="w-full flex items-center justify-between px-5 py-3 rounded-xl border border-border bg-card hover:bg-secondary transition-colors mb-4 text-sm font-medium text-foreground"
            >
              Review Answers
              <ChevronRight className={`h-4 w-4 transition-transform ${showReview ? 'rotate-90' : ''}`} />
            </button>

            <AnimatePresence>
              {showReview && (
                <motion.div
                  key="review"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4 mb-6 overflow-hidden"
                >
                  {questions.map((q, i) => {
                    const selected  = attempt.answers[q.id]
                    // Backend does not send which option was correct in the answer map;
                    // we show the submitted answer with pass/fail colouring per question.
                    const correct   = result.correct
                    return (
                      <div key={q.id} className="rounded-xl border border-border bg-card p-4">
                        <p className="text-sm font-medium text-foreground mb-3">
                          Q{i + 1}: {q.text}
                        </p>
                        <div className="space-y-1.5">
                          {q.options.map(opt => {
                            const wasSelected = opt.id === selected
                            return (
                              <div
                                key={opt.id}
                                className={`px-3 py-1.5 rounded-lg text-xs ${
                                  wasSelected
                                    ? 'bg-primary/15 text-primary border border-primary/30'
                                    : 'bg-secondary text-muted-foreground'
                                }`}
                              >
                                {opt.text}
                                {wasSelected && ' (your answer)'}
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )
                  })}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleRetry}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border border-border text-sm font-semibold text-foreground hover:bg-secondary transition-colors"
              >
                <RotateCcw className="h-4 w-4" />
                Retry Quiz
              </button>
              <Link
                href={`/courses/${slug}/lessons/${lessonId}`}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg bg-secondary border border-border text-sm font-semibold text-foreground hover:bg-muted transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Lesson
              </Link>
              <Link
                href={`/courses/${slug}`}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-colors"
              >
                Course Overview
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  // ── Quiz taking screen ────────────────────────────────────────
  const q    = questions[currentQ]
  const opts = q?.options ?? []

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="mx-auto max-w-2xl px-4 py-12">

          {/* Header */}
          <div className="mb-6">
            <Link
              href={`/courses/${slug}/lessons/${lessonId}`}
              className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" /> Back to lesson
            </Link>
            <h1 className="text-2xl font-bold text-foreground">{quiz.title}</h1>
            <p className="text-muted-foreground text-sm mt-1">
              {questions.length} question{questions.length !== 1 ? 's' : ''} &middot;{' '}
              Passing score: {quiz.passingScore}%
            </p>
          </div>

          {/* Previous best attempt note */}
          {quiz.bestAttempt && (
            <div className={`p-3 rounded-lg border mb-5 text-sm flex items-center gap-2 ${
              quiz.bestAttempt.passed
                ? 'bg-success/10 border-success/30 text-success'
                : 'bg-warning/10 border-warning/30 text-warning'
            }`}>
              {quiz.bestAttempt.passed
                ? <CheckCircle className="h-4 w-4" />
                : <AlertCircle className="h-4 w-4" />
              }
              Best attempt: {quiz.bestAttempt.score}%{' '}
              &mdash; {quiz.bestAttempt.passed ? 'Passed' : 'Failed'}. You can retake anytime.
            </div>
          )}

          {/* Progress bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm text-muted-foreground mb-2">
              <span>Question {currentQ + 1} of {questions.length}</span>
              <span>{Object.keys(answers).length} answered</span>
            </div>
            <div className="progress-bar">
              <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
            </div>
          </div>

          {/* Question navigator dots */}
          <div className="flex flex-wrap gap-1.5 mb-6">
            {questions.map((qs, i) => (
              <button
                key={qs.id}
                onClick={() => setCurrentQ(i)}
                className={`h-8 w-8 rounded-lg text-xs font-bold transition-colors ${
                  i === currentQ
                    ? 'bg-primary text-white'
                    : answers[qs.id]
                      ? 'bg-success/20 text-success border border-success/30'
                      : 'bg-secondary border border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>

          {/* Current question card */}
          <AnimatePresence mode="wait">
            {q && (
              <motion.div
                key={q.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="rounded-xl border border-border bg-card p-6 mb-6"
              >
                <p className="font-semibold text-foreground text-lg mb-5">
                  {currentQ + 1}. {q.text}
                </p>
                <div className="space-y-2.5">
                  {opts.map((opt, oi) => {
                    const selected = answers[q.id] === opt.id
                    return (
                      <button
                        key={opt.id}
                        onClick={() => handleAnswer(q.id, opt.id)}
                        className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                          selected
                            ? 'bg-primary/15 border-primary text-primary'
                            : 'bg-secondary border-border text-foreground hover:border-primary/40 hover:bg-primary/5'
                        }`}
                      >
                        <span className={`inline-flex h-6 w-6 rounded-full items-center justify-center text-xs font-bold mr-3 border ${
                          selected
                            ? 'bg-primary border-primary text-white'
                            : 'border-border text-muted-foreground'
                        }`}>
                          {String.fromCharCode(65 + oi)}
                        </span>
                        {opt.text}
                      </button>
                    )
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation + submit */}
          <div className="flex items-center justify-between gap-3">
            <button
              onClick={() => setCurrentQ(c => Math.max(0, c - 1))}
              disabled={currentQ === 0}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ArrowLeft className="h-4 w-4" /> Previous
            </button>

            <div className="flex items-center gap-2">
              {currentQ < questions.length - 1 && (
                <button
                  onClick={() => setCurrentQ(c => c + 1)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                >
                  Next <ArrowRight className="h-4 w-4" />
                </button>
              )}
              {allAnswered && (
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors glow-primary"
                >
                  {submitting
                    ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    : <Trophy className="h-4 w-4" />
                  }
                  {submitting ? 'Grading...' : 'Submit Quiz'}
                </button>
              )}
            </div>
          </div>

          {!allAnswered && (
            <p className="text-xs text-muted-foreground text-center mt-3">
              Answer all {questions.length} questions to submit
            </p>
          )}
        </div>
      </div>
    </ProtectedRoute>
  )
}
