'use client'
// ============================================================
// STEMQuest — Lesson Page
// GET /api/courses/:slug               — for course outline
// Lesson data is embedded in course.modules[*].lessons[*]
// POST /api/courses/:courseId/lessons/:lessonId/complete
// Sidebar shows ALL modules and lessons for the course.
// ============================================================

import { useState, useEffect, useCallback } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/contexts/AuthContext'
import { courseApi, ApiError } from '@/lib/api'
import type { CourseItem, LessonItem, BadgeItem } from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import ProtectedRoute from '@/components/shared/ProtectedRoute'
import {
  ArrowLeft, ArrowRight, CheckCircle, Trophy, Zap,
  BookOpen, Play, AlertCircle, ChevronRight, ChevronDown,
} from 'lucide-react'

// ── Minimal Markdown renderer (no external deps) ──────────────
function renderMarkdown(md: string): string {
  return md
    .replace(/^#### (.+)/gm, '<h4 class="text-base font-semibold text-foreground mt-4 mb-1">$1</h4>')
    .replace(/^### (.+)/gm, '<h3 class="text-lg font-semibold text-accent mt-5 mb-1">$1</h3>')
    .replace(/^## (.+)/gm, '<h2 class="text-xl font-bold text-foreground mt-6 mb-2 pb-1 border-b border-border">$1</h2>')
    .replace(/^# (.+)/gm, '<h1 class="text-2xl font-bold text-foreground mt-6 mb-3">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/`([^`]+)`/g, '<code class="bg-[#1a2035] text-accent px-1.5 py-0.5 rounded font-mono text-sm">$1</code>')
    .replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre class="bg-[#0d1220] border border-border rounded-lg p-4 overflow-x-auto my-4"><code class="font-mono text-sm text-[#a5f3fc] whitespace-pre">$2</code></pre>')
    .replace(/^\- (.+)/gm, '<li class="ml-4 list-disc text-foreground mb-0.5">$1</li>')
    .replace(/^\d+\. (.+)/gm, '<li class="ml-4 list-decimal text-foreground mb-0.5">$1</li>')
    .replace(/\n\n/g, '</p><p class="mb-3 leading-relaxed text-muted-foreground">')
    .replace(/^(?!<[hpliceptabr])(.+)/gm, '<p class="mb-3 leading-relaxed text-muted-foreground">$1</p>')
}

function LessonContent({ content }: { content: string }) {
  return (
    <div
      className="prose-stemquest"
      dangerouslySetInnerHTML={{ __html: renderMarkdown(content) }}
    />
  )
}

// ── Skeleton ──────────────────────────────────────────────────
function LessonSkeleton() {
  return (
    <div className="min-h-screen bg-background animate-pulse">
      <div className="border-b border-border bg-card h-12" />
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1 h-64 rounded-xl bg-secondary" />
          <div className="lg:col-span-3 space-y-4">
            <div className="h-8 w-3/4 rounded bg-secondary" />
            <div className="h-48 rounded-xl bg-secondary" />
            <div className="h-12 w-48 rounded-lg bg-secondary" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default function LessonPage() {
  const { slug, lessonId } = useParams<{ slug: string; lessonId: string }>()
  const { session } = useAuth()
  const queryClient = useQueryClient()

  const [completionResult, setCompletionResult] = useState<{
    xp: number
    newBadges: BadgeItem[]
  } | null>(null)
  const [completionError, setCompletionError] = useState('')
  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set())

  // ── Course (includes all modules + lessons) ──────────────────
  const { data: course, isLoading } = useQuery<CourseItem, ApiError>({
    queryKey: ['course', slug],
    queryFn:  () => courseApi.detail(slug),
    retry:    (count, err) => err.status !== 404 && count < 2,
  })

  // Derive current lesson from nested structure
  const allLessons: LessonItem[] = (course?.modules ?? []).flatMap(m => m.lessons ?? [])
  const lesson   = allLessons.find(l => l.id === lessonId) ?? null
  const lessonIdx = allLessons.findIndex(l => l.id === lessonId)
  const prevLesson = lessonIdx > 0 ? allLessons[lessonIdx - 1] : null
  const nextLesson = lessonIdx < allLessons.length - 1 ? allLessons[lessonIdx + 1] : null

  // Current module (for sidebar default expand)
  const currentModule = (course?.modules ?? []).find(m =>
    (m.lessons ?? []).some(l => l.id === lessonId)
  )

  // Expand current lesson's module by default
  useEffect(() => {
    if (currentModule) {
      setExpandedModules(prev => new Set([...prev, currentModule.id]))
    }
  }, [currentModule?.id])

  const toggleModule = useCallback((modId: string) => {
    setExpandedModules(prev => {
      const next = new Set(prev)
      next.has(modId) ? next.delete(modId) : next.add(modId)
      return next
    })
  }, [])

  // ── Complete lesson mutation ──────────────────────────────────
  const { mutate: completeLesson, isPending: completing } = useMutation({
    mutationFn: () => courseApi.completeLesson(course!.id, lessonId),
    onSuccess: (data) => {
      setCompletionError('')
      setCompletionResult({ xp: data.xpAwarded, newBadges: data.newBadges })
      // Refresh course data to update lesson.completed state
      queryClient.invalidateQueries({ queryKey: ['course', slug] })
      // Also invalidate gamification / dashboard data
      queryClient.invalidateQueries({ queryKey: ['gamification'] })
    },
    onError: (err: ApiError) => {
      setCompletionError(err.message)
    },
  })

  const handleComplete = () => {
    if (!session || !lesson || !course) return
    setCompletionError('')
    completeLesson()
  }

  // ── Loading / not found ──────────────────────────────────────
  if (isLoading) return <LessonSkeleton />

  if (!course || !lesson) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background">
          <Navbar />
          <div className="flex flex-col items-center justify-center py-32 gap-4">
            <AlertCircle className="h-12 w-12 text-muted-foreground" />
            <p className="font-medium text-foreground">Lesson not found</p>
            <Link href="/courses" className="text-primary hover:underline flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" /> Back to catalog
            </Link>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  const isCompleted = lesson.completed || !!completionResult

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Top breadcrumb bar */}
        <div className="border-b border-border bg-card">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground min-w-0">
              <Link href="/courses" className="hover:text-foreground transition-colors shrink-0">
                Courses
              </Link>
              <ChevronRight className="h-3.5 w-3.5 shrink-0" />
              <Link
                href={`/courses/${slug}`}
                className="hover:text-foreground transition-colors truncate max-w-36"
              >
                {course.title}
              </Link>
              <ChevronRight className="h-3.5 w-3.5 shrink-0" />
              <span className="text-foreground font-medium truncate">{lesson.title}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="flex items-center gap-1 text-xs text-gold font-medium">
                <Trophy className="h-3.5 w-3.5" />
                {lesson.xpReward} XP
              </span>
              {isCompleted && (
                <span className="flex items-center gap-1 text-xs text-success font-medium">
                  <CheckCircle className="h-3.5 w-3.5" />
                  Completed
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* ── Sidebar — full course outline ──────────────── */}
            <div className="lg:col-span-1 order-2 lg:order-1">
              <div className="rounded-xl border border-border bg-card p-4 sticky top-20 max-h-[calc(100vh-6rem)] overflow-y-auto">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-semibold text-foreground">Course Outline</h3>
                </div>

                {(course.modules ?? []).map(mod => {
                  const modLessons  = mod.lessons ?? []
                  const expanded    = expandedModules.has(mod.id)
                  const isCurrMod   = mod.id === currentModule?.id
                  return (
                    <div key={mod.id} className="mb-2">
                      <button
                        onClick={() => toggleModule(mod.id)}
                        className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-semibold transition-colors ${
                          isCurrMod
                            ? 'bg-primary/10 text-primary'
                            : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                        }`}
                      >
                        <span className="truncate text-left">{mod.title}</span>
                        {expanded
                          ? <ChevronDown className="h-3.5 w-3.5 shrink-0 ml-1" />
                          : <ChevronRight className="h-3.5 w-3.5 shrink-0 ml-1" />
                        }
                      </button>

                      {expanded && (
                        <div className="mt-1 space-y-0.5 pl-2">
                          {modLessons.map(l => {
                            const done      = l.completed
                            const isCurrent = l.id === lessonId
                            return (
                              <Link
                                key={l.id}
                                href={`/courses/${slug}/lessons/${l.id}`}
                                className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
                                  isCurrent
                                    ? 'bg-primary/15 text-primary font-semibold'
                                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                                }`}
                              >
                                {done
                                  ? <CheckCircle className="h-3.5 w-3.5 text-success shrink-0" />
                                  : <Play className="h-3.5 w-3.5 shrink-0" />
                                }
                                <span className="truncate">{l.title}</span>
                              </Link>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>

            {/* ── Main content ────────────────────────────────── */}
            <div className="lg:col-span-3 order-1 lg:order-2">
              {/* Lesson header */}
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-foreground mb-2">{lesson.title}</h1>
                <p className="text-muted-foreground">{lesson.summary}</p>
              </div>

              {/* Video embed */}
              {lesson.videoUrl && (
                <div className="mb-8 rounded-xl overflow-hidden border border-border aspect-video">
                  <iframe
                    src={lesson.videoUrl}
                    className="w-full h-full"
                    title={lesson.title}
                    allowFullScreen
                  />
                </div>
              )}

              {/* Lesson content */}
              <div className="rounded-xl border border-border bg-card p-6 mb-6">
                <LessonContent content={lesson.content} />
              </div>

              {/* Completion error banner */}
              {completionError && (
                <div className="mb-4 p-4 rounded-xl bg-destructive/10 border border-destructive/30 flex items-center gap-3">
                  <AlertCircle className="h-5 w-5 text-destructive shrink-0" />
                  <div>
                    <p className="font-semibold text-destructive">Cannot mark lesson complete</p>
                    <p className="text-sm text-muted-foreground">{completionError}</p>
                  </div>
                </div>
              )}

              {/* Completion success banner */}
              {completionResult && (
                <div className="mb-6 p-4 rounded-xl bg-success/10 border border-success/30 flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-success shrink-0" />
                  <div>
                    <p className="font-semibold text-success">Lesson completed!</p>
                    <p className="text-sm text-muted-foreground">
                      +{completionResult.xp} XP awarded
                      {completionResult.newBadges.length > 0 &&
                        ` · New badge: ${completionResult.newBadges.map(b => b.name).join(', ')}`
                      }
                    </p>
                  </div>
                </div>
              )}

              {/* Action row */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                {/* Complete button */}
                {!isCompleted ? (
                  <button
                    onClick={handleComplete}
                    disabled={completing}
                    className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors glow-primary"
                  >
                    {completing
                      ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                      : <Zap className="h-4 w-4" />
                    }
                    {completing ? 'Marking complete...' : `Mark Complete (+${lesson.xpReward} XP)`}
                  </button>
                ) : (
                  <div className="flex items-center gap-2 px-5 py-3 rounded-lg bg-success/15 border border-success/30 text-success font-semibold">
                    <CheckCircle className="h-4 w-4" />
                    Lesson Completed
                  </div>
                )}

                {/* Take quiz */}
                {lesson.hasQuiz && (
                  <Link
                    href={`/courses/${slug}/lessons/${lessonId}/quiz`}
                    className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-secondary border border-border text-foreground font-semibold hover:bg-muted transition-colors"
                  >
                    <Trophy className="h-4 w-4" />
                    Take Quiz
                  </Link>
                )}
              </div>

              {/* Prev / Next navigation */}
              <div className="flex justify-between mt-8 pt-6 border-t border-border">
                {prevLesson ? (
                  <Link
                    href={`/courses/${slug}/lessons/${prevLesson.id}`}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span className="max-w-36 truncate">{prevLesson.title}</span>
                  </Link>
                ) : <div />}
                {nextLesson ? (
                  <Link
                    href={`/courses/${slug}/lessons/${nextLesson.id}`}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                  >
                    <span className="max-w-36 truncate">{nextLesson.title}</span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                ) : (
                  <Link
                    href={`/courses/${slug}`}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg border border-primary/30 bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition-colors"
                  >
                    Back to Course
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
