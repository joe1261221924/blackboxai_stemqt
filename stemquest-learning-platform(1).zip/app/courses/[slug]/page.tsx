'use client'
// ============================================================
// STEMQuest — Course Detail Page
// GET /api/courses/:slug  — course + modules + lessons + progress
// POST /api/courses/:slug/enroll  — enrol (free)
// POST /api/billing/create-order  — PayPal checkout (paid)
// ============================================================

import { useState, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/contexts/AuthContext'
import { courseApi, billingApi, ApiError } from '@/lib/api'
import type { CourseItem, LessonItem } from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import {
  BookOpen, Clock, Star, Lock, CheckCircle, ChevronDown,
  ChevronRight, Play, Trophy, Zap, ArrowLeft, Users,
  AlertCircle, CreditCard,
} from 'lucide-react'

const difficultyColors: Record<string, string> = {
  beginner:     'bg-success/20 text-success',
  intermediate: 'bg-warning/20 text-warning',
  advanced:     'bg-destructive/20 text-destructive',
}

// ── Skeleton ──────────────────────────────────────────────────
function CourseSkeleton() {
  return (
    <div className="min-h-screen bg-background animate-pulse">
      <div className="border-b border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
          <div className="h-4 w-24 rounded bg-secondary mb-6" />
          <div className="grid lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2 space-y-4">
              <div className="h-8 w-3/4 rounded bg-secondary" />
              <div className="h-20 rounded bg-secondary" />
              <div className="h-4 w-1/2 rounded bg-secondary" />
            </div>
            <div className="h-64 rounded-xl bg-secondary" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default function CourseDetailPage() {
  const { slug } = useParams<{ slug: string }>()
  const { session } = useAuth()
  const router = useRouter()
  const queryClient = useQueryClient()

  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set())
  const [enrollError, setEnrollError] = useState('')

  // ── Course detail query ──────────────────────────────────────
  const { data: course, isLoading, error: fetchError } = useQuery<CourseItem, ApiError>({
    queryKey: ['course', slug],
    queryFn:  () => courseApi.detail(slug),
    retry:    (count, err) => err.status !== 404 && count < 2,
  })

  // ── Enrol mutation (free courses) ────────────────────────────
  const { mutate: enroll, isPending: enrolling } = useMutation<void, ApiError>({
    mutationFn: () => courseApi.enroll(slug),
    onSuccess: () => {
      // Re-fetch the course to get updated isEnrolled/hasAccess flags
      queryClient.invalidateQueries({ queryKey: ['course', slug] })
      queryClient.invalidateQueries({ queryKey: ['courses'] })
      setEnrollError('')
    },
    onError: (err) => setEnrollError(err.message),
  })

  // ── PayPal buy mutation (premium courses) ────────────────────
  const { mutate: buy, isPending: buying } = useMutation<
    { approvalUrl: string }, ApiError
  >({
    mutationFn: () => billingApi.createOrder(course!.id),
    onSuccess: (data) => router.push(data.approvalUrl),
    onError:   (err) => setEnrollError(err.message),
  })

  const toggleModule = useCallback((id: string) => {
    setExpandedModules(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }, [])

  const handleEnroll = () => {
    if (!session) { router.push('/login'); return }
    setEnrollError('')
    enroll()
  }

  const handleBuy = () => {
    if (!session) { router.push('/login'); return }
    setEnrollError('')
    buy()
  }

  // ── Loading / error states ───────────────────────────────────
  if (isLoading) return <CourseSkeleton />

  if (fetchError || !course) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-32 gap-4">
          <AlertCircle className="h-12 w-12 text-muted-foreground" />
          <p className="text-foreground font-medium text-lg">
            {fetchError?.status === 404 ? 'Course not found' : 'Failed to load course'}
          </p>
          <Link href="/courses" className="text-primary hover:underline flex items-center gap-1">
            <ArrowLeft className="h-4 w-4" />
            Back to catalog
          </Link>
        </div>
      </div>
    )
  }

  // ── Derived state ────────────────────────────────────────────
  const progress      = course.progress
  const isEnrolled    = course.isEnrolled
  const hasAccess     = course.hasAccess

  // First incomplete (or first) lesson across all modules
  const allLessons: LessonItem[] = (course.modules ?? [])
    .flatMap(m => m.lessons ?? [])
  const continueLessonId = allLessons.find(l => !l.completed)?.id ?? allLessons[0]?.id
  const continuePath = continueLessonId
    ? `/courses/${course.slug}/lessons/${continueLessonId}`
    : `/courses/${course.slug}`

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* ── Hero ──────────────────────────────────────────────── */}
      <div className="border-b border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
          <Link
            href="/courses"
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Catalog
          </Link>

          <div className="grid lg:grid-cols-3 gap-10">
            {/* Course info */}
            <div className="lg:col-span-2">
              <div className="flex flex-wrap gap-2 mb-4">
                <span className={`badge-pill ${difficultyColors[course.difficulty] || 'bg-muted text-muted-foreground'}`}>
                  {course.difficulty}
                </span>
                <span className="badge-pill bg-primary/15 text-primary">{course.category}</span>
                {!course.isFree && (
                  <span className="badge-pill bg-[oklch(0.62_0.25_295)/0.2] text-[oklch(0.75_0.22_295)] flex items-center gap-1">
                    <Lock className="h-3 w-3" />
                    Premium
                  </span>
                )}
              </div>

              <h1 className="text-3xl font-bold text-foreground mb-3">{course.title}</h1>
              <p className="text-muted-foreground leading-relaxed mb-6">{course.description}</p>

              <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <BookOpen className="h-4 w-4" />
                  {course.totalLessons} lessons
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4" />
                  ~{course.estimatedHours}h
                </span>
                {course.instructorName && (
                  <span className="flex items-center gap-1.5">
                    <Star className="h-4 w-4 text-gold fill-gold" />
                    by {course.instructorName}
                  </span>
                )}
              </div>

              {/* Progress bar for enrolled students */}
              {isEnrolled && progress && (
                <div className="mt-6 p-4 rounded-xl bg-primary/10 border border-primary/20">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium text-foreground">Your Progress</span>
                    <span className="text-primary font-bold">{progress.percentage}%</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-bar-fill" style={{ width: `${progress.percentage}%` }} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1.5">
                    {progress.completedLessons} of {progress.totalLessons} lessons completed
                  </p>
                </div>
              )}
            </div>

            {/* Enrol / Purchase card */}
            <div className="lg:col-span-1">
              <div className="rounded-xl border border-border bg-background p-6 sticky top-20">
                <div className="aspect-video rounded-lg overflow-hidden mb-5 bg-secondary">
                  <img
                    src={course.imageUrl || `https://placehold.co/800x450?text=${encodeURIComponent(course.title)}`}
                    alt={`Cover image for ${course.title}`}
                    className="w-full h-full object-cover"
                    onError={e => {
                      (e.target as HTMLImageElement).src =
                        `https://placehold.co/800x450?text=${encodeURIComponent(course.title)}`
                    }}
                  />
                </div>

                <div className="mb-5">
                  <p className={`text-3xl font-bold ${course.isFree ? 'text-success' : 'text-[oklch(0.75_0.22_295)]'}`}>
                    {course.isFree ? 'Free' : `$${course.price.toFixed(2)} USD`}
                  </p>
                  {!course.isFree && (
                    <p className="text-xs text-muted-foreground mt-0.5">
                      One-time payment — lifetime access
                    </p>
                  )}
                </div>

                {enrollError && (
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-xs mb-4">
                    <AlertCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                    {enrollError}
                  </div>
                )}

                {/* CTA button */}
                {isEnrolled ? (
                  <Link
                    href={continuePath}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 transition-colors glow-primary"
                  >
                    <Play className="h-4 w-4" />
                    Continue Learning
                  </Link>
                ) : hasAccess ? (
                  <button
                    onClick={handleEnroll}
                    disabled={enrolling}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors glow-primary"
                  >
                    {enrolling ? (
                      <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    ) : (
                      <Zap className="h-4 w-4" />
                    )}
                    Enrol Now — Free
                  </button>
                ) : (
                  <button
                    onClick={handleBuy}
                    disabled={buying}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-[oklch(0.62_0.25_295)] text-white font-semibold hover:opacity-90 disabled:opacity-60 transition-opacity"
                  >
                    {buying
                      ? <span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                      : <CreditCard className="h-4 w-4" />
                    }
                    {buying ? 'Redirecting...' : `Purchase — $${course.price.toFixed(2)}`}
                  </button>
                )}

                {!session && (
                  <p className="text-center text-xs text-muted-foreground mt-3">
                    <Link href="/register" className="text-primary hover:underline">
                      Create a free account
                    </Link>{' '}
                    to enrol
                  </p>
                )}

                <div className="mt-5 space-y-2 text-sm text-muted-foreground">
                  {[
                    `${course.totalLessons} structured lessons`,
                    'XP and badges on completion',
                    'Quizzes with adaptive feedback',
                    'Lifetime access',
                  ].map(item => (
                    <div key={item} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-success shrink-0" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Curriculum ────────────────────────────────────────── */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="max-w-3xl">
          <h2 className="text-2xl font-bold text-foreground mb-6">Course Curriculum</h2>

          {(!course.modules || course.modules.length === 0) ? (
            <p className="text-muted-foreground">No modules yet. Check back soon.</p>
          ) : (
            <div className="space-y-3">
              {course.modules.map(mod => {
                const lessons   = mod.lessons ?? []
                const expanded  = expandedModules.has(mod.id)
                const doneCt    = lessons.filter(l => l.completed).length

                return (
                  <div key={mod.id} className="rounded-xl border border-border bg-card overflow-hidden">
                    <button
                      className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors text-left"
                      onClick={() => toggleModule(mod.id)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                          {mod.order}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{mod.title}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {lessons.length} lesson{lessons.length !== 1 ? 's' : ''}
                            {isEnrolled && (
                              <span> · {doneCt}/{lessons.length} completed</span>
                            )}
                          </p>
                        </div>
                      </div>
                      {expanded
                        ? <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
                        : <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                      }
                    </button>

                    {expanded && (
                      <div className="border-t border-border divide-y divide-border">
                        {lessons.map(lesson => {
                          const locked = !course.isFree && !hasAccess
                          return (
                            <div
                              key={lesson.id}
                              className="flex items-center justify-between px-4 py-3 hover:bg-secondary/30 transition-colors"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                {lesson.completed ? (
                                  <CheckCircle className="h-4 w-4 text-success shrink-0" />
                                ) : locked ? (
                                  <Lock className="h-4 w-4 text-muted-foreground shrink-0" />
                                ) : (
                                  <Play className="h-4 w-4 text-primary shrink-0" />
                                )}
                                <div className="min-w-0">
                                  <p className={`text-sm font-medium truncate ${locked ? 'text-muted-foreground' : 'text-foreground'}`}>
                                    {lesson.title}
                                  </p>
                                  {lesson.summary && (
                                    <p className="text-xs text-muted-foreground truncate">
                                      {lesson.summary.slice(0, 70)}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-3 shrink-0 ml-3">
                                <span className="flex items-center gap-1 text-xs text-gold whitespace-nowrap">
                                  <Trophy className="h-3 w-3" />
                                  {lesson.xpReward} XP
                                </span>
                                {isEnrolled && !locked && (
                                  <Link
                                    href={`/courses/${course.slug}/lessons/${lesson.id}`}
                                    className="text-xs text-primary hover:underline whitespace-nowrap"
                                  >
                                    {lesson.completed ? 'Review' : 'Start'}
                                  </Link>
                                )}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
