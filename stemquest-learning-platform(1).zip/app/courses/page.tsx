'use client'
// ============================================================
// STEMQuest — Course Catalog
// Calls GET /api/courses — public, returns per-user metadata
// if the user is authenticated (via cookie).
// useSearchParams() is called inside CoursesCatalogInner which
// is wrapped in <Suspense> in the default export below.
// ============================================================

import { useState, useMemo, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import { useAuth } from '@/contexts/AuthContext'
import { courseApi, ApiError } from '@/lib/api'
import type { CourseItem } from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import CourseCard from '@/components/shared/CourseCard'
import { Search, Filter, BookOpen, Zap, AlertCircle } from 'lucide-react'

const CATEGORIES    = ['All', 'Computer Science', 'Mathematics', 'Engineering', 'Physics']
const DIFFICULTIES  = ['All', 'beginner', 'intermediate', 'advanced']
const PRICE_FILTERS = ['All', 'Free', 'Premium']

// ── Inner component (uses useSearchParams) ───────────────────
function CoursesCatalogInner() {
  const { session } = useAuth()
  const searchParams = useSearchParams()

  const [search,       setSearch]       = useState('')
  const [category,     setCategory]     = useState('All')
  const [difficulty,   setDifficulty]   = useState('All')
  const [priceFilter,  setPriceFilter]  = useState('All')

  // Apply ?category= URL param on first render
  useEffect(() => {
    const urlCat = searchParams.get('category')
    if (urlCat && CATEGORIES.includes(urlCat)) setCategory(urlCat)
  }, [searchParams])

  // ── Real API call via TanStack Query ─────────────────────
  const { data: allCourses = [], isLoading, error } = useQuery<CourseItem[], ApiError>({
    queryKey: ['courses', session?.userId],   // re-fetch when auth state changes
    queryFn:  () => courseApi.list(),
    staleTime: 60_000,
  })

  // ── Client-side filtering ─────────────────────────────────
  const filtered = useMemo(() => {
    const q = search.toLowerCase()
    return allCourses.filter(c => {
      const matchSearch = !search
        || c.title.toLowerCase().includes(q)
        || c.description.toLowerCase().includes(q)
        || c.category.toLowerCase().includes(q)
      const matchCat   = category === 'All' || c.category === category
      const matchDiff  = difficulty === 'All' || c.difficulty === difficulty
      const matchPrice = priceFilter === 'All'
        || (priceFilter === 'Free' ? c.isFree : !c.isFree)
      return matchSearch && matchCat && matchDiff && matchPrice
    })
  }, [allCourses, search, category, difficulty, priceFilter])

  const clearFilters = () => {
    setSearch('')
    setCategory('All')
    setDifficulty('All')
    setPriceFilter('All')
  }

  const hasActiveFilters =
    search || category !== 'All' || difficulty !== 'All' || priceFilter !== 'All'

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">STEM Course Catalog</h1>
          <p className="text-muted-foreground">
            {isLoading
              ? 'Loading courses…'
              : `${allCourses.length} course${allCourses.length !== 1 ? 's' : ''} across Computer Science, Mathematics, Physics, and Engineering`}
          </p>
        </div>

        {/* Error state */}
        {error && (
          <div className="flex items-center gap-3 p-4 mb-6 rounded-xl bg-destructive/10 border border-destructive/30 text-destructive">
            <AlertCircle className="h-5 w-5 shrink-0" />
            <p className="text-sm">Failed to load courses. Please refresh the page.</p>
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-col gap-4 mb-8">
          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search courses..."
              className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
            />
          </div>

          {/* Filter pills */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium shrink-0">
              <Filter className="h-3.5 w-3.5" />
              Filters:
            </span>

            {/* Category */}
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    category === cat
                      ? 'bg-primary text-white'
                      : 'bg-secondary border border-border text-muted-foreground hover:text-foreground hover:border-primary/40'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-border hidden sm:block" />

            {/* Price */}
            <div className="flex gap-1.5">
              {PRICE_FILTERS.map(p => (
                <button
                  key={p}
                  onClick={() => setPriceFilter(p)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    priceFilter === p
                      ? 'bg-primary text-white'
                      : 'bg-secondary border border-border text-muted-foreground hover:text-foreground hover:border-primary/40'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-border hidden sm:block" />

            {/* Difficulty */}
            <div className="flex gap-1.5">
              {DIFFICULTIES.map(d => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`px-3 py-1 rounded-full text-xs font-medium capitalize transition-colors ${
                    difficulty === d
                      ? 'bg-primary text-white'
                      : 'bg-secondary border border-border text-muted-foreground hover:text-foreground hover:border-primary/40'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results count */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-muted-foreground">
            Showing{' '}
            <span className="font-medium text-foreground">{filtered.length}</span>{' '}
            course{filtered.length !== 1 ? 's' : ''}
            {search && (
              <span>
                {' '}for &ldquo;<span className="text-primary">{search}</span>&rdquo;
              </span>
            )}
          </p>
          {hasActiveFilters && (
            <button onClick={clearFilters} className="text-xs text-primary hover:underline">
              Clear all filters
            </button>
          )}
        </div>

        {/* Loading skeleton */}
        {isLoading && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="rounded-xl border border-border bg-card overflow-hidden animate-pulse">
                <div className="aspect-video bg-secondary" />
                <div className="p-4 space-y-3">
                  <div className="h-3 w-1/2 rounded bg-secondary" />
                  <div className="h-5 w-3/4 rounded bg-secondary" />
                  <div className="h-3 w-full rounded bg-secondary" />
                  <div className="h-3 w-2/3 rounded bg-secondary" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Course grid */}
        {!isLoading && filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="p-4 rounded-xl bg-secondary">
              <BookOpen className="h-10 w-10 text-muted-foreground" />
            </div>
            <p className="text-foreground font-medium">No courses match your filters</p>
            <p className="text-muted-foreground text-sm">Try adjusting your search or filter criteria</p>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                Clear Filters
              </button>
            )}
          </div>
        )}

        {!isLoading && filtered.length > 0 && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(course => (
              <CourseCard
                key={course.id}
                course={course}
                showProgress={!!session && course.isEnrolled}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Suspense fallback ─────────────────────────────────────────
function CatalogFallback() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="flex items-center justify-center py-32 gap-3">
        <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center animate-pulse">
          <Zap className="h-5 w-5 text-primary" />
        </div>
        <p className="text-muted-foreground">Loading courses...</p>
      </div>
    </div>
  )
}

// ── Default export wraps in Suspense ──────────────────────────
// Next.js App Router requires useSearchParams() callers to run
// inside a <Suspense> boundary to avoid build-time errors.
export default function CoursesPage() {
  return (
    <Suspense fallback={<CatalogFallback />}>
      <CoursesCatalogInner />
    </Suspense>
  )
}
