'use client'
// ============================================================
// STEMQuest — Billing Cancel Page
// User cancelled payment on PayPal — no charge made.
// ============================================================

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/shared/Navbar'
import { XCircle, ArrowLeft, BookOpen } from 'lucide-react'

export default function BillingCancelPage() {
  const router = useRouter()
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="flex flex-col items-center justify-center py-24 px-4 text-center">
        <div className="max-w-md w-full">
          <div className="rounded-2xl border border-border bg-card p-10 mb-8">
            <div className="flex justify-center mb-6">
              <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
                <XCircle className="h-10 w-10 text-muted-foreground" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-3">Payment Cancelled</h1>
            <p className="text-muted-foreground leading-relaxed">
              Your payment was cancelled and you have not been charged. You can try
              again at any time from the course page.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => router.back()}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-white font-semibold hover:bg-primary/90 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </button>
            <Link
              href="/courses"
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-border bg-secondary text-foreground font-semibold hover:bg-muted transition-colors"
            >
              <BookOpen className="h-4 w-4" />
              Browse Courses
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
