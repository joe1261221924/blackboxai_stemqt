'use client'
// ============================================================
// STEMQuest — Billing Success Page
// PayPal redirects here after the user approves payment.
// URL: /billing/success?token=<paypal_order_id>
//
// Calls POST /api/billing/capture with { paypal_order_id: token }
// Receives: { course_id, course_slug, course_title, purchase_id }
//
// useSearchParams() requires a <Suspense> boundary — see default export.
// ============================================================

import { useEffect, useRef, useState, Suspense } from 'react'
import Link from 'next/link'
import { useSearchParams, useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import { billingApi, courseApi, ApiError } from '@/lib/api'
import Navbar from '@/components/shared/Navbar'
import { CheckCircle, AlertCircle, Zap, ArrowRight, BookOpen } from 'lucide-react'

type State = 'processing' | 'success' | 'error' | 'unauthenticated'

// ── Inner component (uses useSearchParams) ──────────────────
function BillingSuccessInner() {
  const { session, isAuthenticated, loading } = useAuth()
  const searchParams = useSearchParams()
  const router       = useRouter()

  // PayPal sends the order ID as `token` in the return URL
  const paypalOrderId = searchParams.get('token') || ''

  const [state,       setState]       = useState<State>('processing')
  const [courseSlug,  setCourseSlug]  = useState('')
  const [courseTitle, setCourseTitle] = useState('')
  const [errorMsg,    setErrorMsg]    = useState('')

  // Prevent capture from running more than once even if deps change
  const capturedRef = useRef(false)

  useEffect(() => {
    if (loading) return

    if (!isAuthenticated || !session) {
      setState('unauthenticated')
      return
    }

    if (!paypalOrderId) {
      setState('error')
      setErrorMsg('No payment token found in the URL. Please try your purchase again.')
      return
    }

    // Guard: capture exactly once per mount
    if (capturedRef.current) return
    capturedRef.current = true

    ;(async () => {
      try {
        // POST /api/billing/capture — idempotent on PayPal side
        const result = await billingApi.captureOrder(paypalOrderId)
        setCourseSlug(result.courseSlug)
        setCourseTitle(result.courseTitle)
        // Auto-enroll the student now that purchase is confirmed.
        // Enroll is idempotent — safe to call even if already enrolled.
        if (result.courseSlug) {
          try { await courseApi.enroll(result.courseSlug) } catch { /* already enrolled or free — ignore */ }
        }
        setState('success')
      } catch (err) {
        setState('error')
        if (err instanceof ApiError) {
          setErrorMsg(err.message)
        } else {
          setErrorMsg('Payment capture failed. Please contact support.')
        }
      }
    })()
  }, [loading, isAuthenticated, session, paypalOrderId])

  // ── Processing / Loading ─────────────────────────────────
  if (loading || state === 'processing') {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-32 gap-4">
          <div className="h-14 w-14 rounded-2xl bg-primary/20 flex items-center justify-center animate-pulse">
            <Zap className="h-7 w-7 text-primary" />
          </div>
          <p className="text-muted-foreground">Processing your payment...</p>
          <p className="text-xs text-muted-foreground">Please do not close this page</p>
        </div>
      </div>
    )
  }

  // ── Unauthenticated ──────────────────────────────────────
  if (state === 'unauthenticated') {
    const redirectTarget = `/billing/success?token=${encodeURIComponent(paypalOrderId)}`
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-32 gap-4">
          <AlertCircle className="h-12 w-12 text-warning" />
          <p className="font-medium text-foreground">Please sign in to complete your purchase</p>
          <Link
            href={`/login?redirect=${encodeURIComponent(redirectTarget)}`}
            className="px-6 py-2.5 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 transition-colors"
          >
            Sign In
          </Link>
        </div>
      </div>
    )
  }

  // ── Error ────────────────────────────────────────────────
  if (state === 'error') {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-24 px-4 text-center gap-5">
          <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/30">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground mb-2">Payment Issue</h1>
            <p className="text-muted-foreground max-w-sm">{errorMsg}</p>
          </div>
          <div className="flex gap-3">
            <Link
              href="/courses"
              className="px-5 py-2.5 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-secondary transition-colors"
            >
              Browse Courses
            </Link>
            <button
              onClick={() => router.back()}
              className="px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              Go Back
            </button>
          </div>
        </div>
      </div>
    )
  }

  // ── Success ──────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="flex flex-col items-center justify-center py-24 px-4 text-center">
        <div className="max-w-lg w-full">
          <div className="rounded-2xl border border-success/30 bg-success/10 p-10 mb-8">
            <div className="flex justify-center mb-6">
              <div className="h-20 w-20 rounded-full bg-success/20 flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-success" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-3">Purchase Successful!</h1>
            {courseTitle && (
              <p className="font-semibold text-primary mb-3">{courseTitle}</p>
            )}
            <p className="text-muted-foreground leading-relaxed">
              Your payment is confirmed and you are now enrolled in the course.
              Start learning and earning XP right away!
            </p>
            <div className="flex flex-wrap justify-center gap-4 mt-6 text-sm">
              {[
                'Payment confirmed',
                'Course unlocked',
                'Enrolled automatically',
              ].map(label => (
                <span key={label} className="flex items-center gap-1.5 text-success">
                  <CheckCircle className="h-4 w-4" />
                  {label}
                </span>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            {courseSlug && (
              <Link
                href={`/courses/${courseSlug}`}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-white font-semibold hover:bg-primary/90 transition-colors glow-primary"
              >
                <BookOpen className="h-5 w-5" />
                Go to Course
                <ArrowRight className="h-4 w-4" />
              </Link>
            )}
            <Link
              href={session?.role === 'admin' ? '/admin' : '/dashboard'}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-border bg-secondary text-foreground font-semibold hover:bg-muted transition-colors"
            >
              <Zap className="h-5 w-5" />
              My Dashboard
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Suspense fallback ────────────────────────────────────────
function BillingFallback() {
  return (
    <div className="min-h-screen bg-background">
      <div className="flex flex-col items-center justify-center py-32 gap-4">
        <div className="h-14 w-14 rounded-2xl bg-primary/20 flex items-center justify-center animate-pulse">
          <Zap className="h-7 w-7 text-primary" />
        </div>
        <p className="text-muted-foreground">Loading...</p>
      </div>
    </div>
  )
}

// ── Default export wraps in Suspense ──────────────────────────
export default function BillingSuccessPage() {
  return (
    <Suspense fallback={<BillingFallback />}>
      <BillingSuccessInner />
    </Suspense>
  )
}
