'use client'
// ============================================================
// STEMQuest — Login Page
// ============================================================

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import { Zap, Eye, EyeOff, AlertCircle, LogIn, Trophy, Flame, BarChart3 } from 'lucide-react'

const DEMO_ACCOUNTS = [
  { label: 'Student Demo', email: 'student@demo.test', role: 'Student' },
  { label: 'Admin Demo',   email: 'admin@demo.test',   role: 'Admin'   },
]

export default function LoginPage() {
  const { login, isAuthenticated, session } = useAuth()
  const router = useRouter()

  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw]     = useState(false)
  const [error, setError]       = useState('')
  const [loading, setLoading]   = useState(false)

  // Redirect if already logged in
  useEffect(() => {
    if (!isAuthenticated || !session) return
    if (session.role === 'admin') router.replace('/admin')
    else router.replace('/dashboard')
  }, [isAuthenticated, session, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!email.trim() || !password) { setError('Please enter your email and password.'); return }
    setLoading(true)
    const result = await login(email.trim().toLowerCase(), password)
    setLoading(false)
    if (result.error) setError(result.error)
  }

  const fillDemo = (demoEmail: string) => {
    setEmail(demoEmail)
    setPassword('password123')
    setError('')
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left panel — branding */}
      <div className="hidden lg:flex lg:w-1/2 flex-col items-center justify-center p-12 bg-card border-r border-border relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute top-1/4 left-1/4 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 h-48 w-48 rounded-full bg-accent/10 blur-3xl" />
        </div>
        <div className="relative z-10 max-w-sm text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="h-14 w-14 rounded-2xl bg-primary flex items-center justify-center glow-primary">
              <Zap className="h-7 w-7 text-white" />
            </div>
            <span className="text-4xl font-extrabold text-gradient-primary">STEMQuest</span>
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-4">Welcome back, Quester</h2>
          <p className="text-muted-foreground leading-relaxed">
            Pick up where you left off. Your streaks, badges, and progress are waiting.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-4 text-center">
            {[
              { label: 'XP System',   Icon: Trophy  },
              { label: 'Streaks',     Icon: Flame   },
              { label: 'Leaderboard', Icon: BarChart3 },
            ].map(({ label, Icon }) => (
              <div key={label} className="p-3 rounded-xl bg-secondary border border-border">
                <div className="flex justify-center mb-2">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <p className="text-xs text-muted-foreground font-medium">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-8">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex items-center justify-center gap-2 mb-8 lg:hidden">
            <div className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <span className="text-2xl font-extrabold text-gradient-primary">STEMQuest</span>
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold text-foreground">Sign in to your account</h1>
            <p className="text-muted-foreground mt-1">
              Don&apos;t have an account?{' '}
              <Link href="/register" className="text-primary hover:underline font-medium">Create one free</Link>
            </p>
          </div>

          {/* Demo quick-fill */}
          <div className="mb-6">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Quick demo access</p>
            <div className="flex flex-col gap-2">
              {DEMO_ACCOUNTS.map(({ label, email: demoEmail, role }) => (
                <button
                  key={demoEmail}
                  type="button"
                  onClick={() => fillDemo(demoEmail)}
                  className="flex items-center justify-between px-3 py-2 rounded-lg border border-border bg-secondary hover:bg-muted transition-colors text-left"
                >
                  <span className="text-sm font-medium text-foreground">{label}</span>
                  <span className="badge-pill bg-primary/15 text-primary text-xs">{role}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="relative my-5">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
            <div className="relative flex justify-center"><span className="bg-background px-3 text-xs text-muted-foreground">or enter manually</span></div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm mb-4">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Email address</label>
              <input
                type="email"
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Password</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 pr-11 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 disabled:opacity-60 disabled:cursor-not-allowed transition-colors glow-primary mt-2"
            >
              {loading ? (
                <span className="h-5 w-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <LogIn className="h-5 w-5" />
              )}
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-xs text-muted-foreground mt-6">
            Demo password for all accounts:{' '}
            <code className="bg-secondary px-1.5 py-0.5 rounded text-foreground font-mono">password123</code>
          </p>
        </div>
      </div>
    </div>
  )
}
